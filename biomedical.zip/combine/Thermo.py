import pandas as pd
from bs4 import BeautifulSoup
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import sys

now_path = '/usr/src/app/'
print('--Loading data ...')
Thermo_check_data = sys.argv[1] #'Run_dimer_C.csv'
Thermo_mode = int(sys.argv[2]) # 1 or 2

Data = pd.read_csv(now_path+Thermo_check_data)

IDs = Data['ID'].values
texts = []
for num in range(len(Data)) :
    text = '\n'
    text += 'F3 '
    text += Data['F3_Sequence'].values[num] + '\n'

    text += 'B3 '
    text += Data['B3_Sequence'].values[num] + '\n'

    text += 'FIP '
    text += Data['F1c_Sequence'].values[num] + Data['F2_Sequence'].values[num] + '\n'

    text += 'BIP '
    text += Data['B1c_Sequence'].values[num] + Data['B2_Sequence'].values[num] + '\n'

    text += 'LF '
    text += Data['LF_Sequence'].values[num] + '\n'

    text += 'LB '
    text += Data['LB_Sequence'].values[num] + '\n'
    
    if Thermo_mode != 1 :
        text += 'TFO '
        try:
            text += Data['TFO_Sequence'].values[num] + '\n'
        except:
            text += Data['TTS_Sequence'].values[num] + '\n'

    texts.append(text)
print('--Loading data finish')
def searching(target) :

    string_start = str(soup).find(target)
    string_end = string_start + str(soup)[string_start:].find('" ')
    search_xpath = str(soup)[string_start:string_end]

    canvas = driver.find_element_by_xpath('//*[@id="'+search_xpath+'"]')

    #ActionChains(driver).move_to_element(canvas).click().key_down(Keys.CONTROL).send_keys('a').perform()
    #ActionChains(driver).key_down(Keys.CONTROL).send_keys('c').perform()

    return (canvas.get_attribute('value'))


if Thermo_mode == 1:
    list1 = ['F3','B3','FIP','BIP','LF','LB']
else:
    list1 = ['F3','B3','FIP','BIP','LF','LB','TFO']
list2 = ['Sequence','Tm','CG','nt','A','T','C','G','Extinction_coefficient','Molecular_weight','nmol','ug/OD260']
columns = []
for each in list1 :
    for each2 in list2 :
        columns.append(each+'_'+each2)

print('--Open Web ...')
chrome_options = Options()
chrome_options.add_argument('--headless')
driver = Chrome(chrome_options=chrome_options)

driver.get("https://www.thermofisher.com/tw/zt/home/brands/thermo-scientific/molecular-biology/molecular-biology-learning-center/molecular-biology-resource-library/thermo-scientific-web-tools/multiple-primer-analyzer.html")
soup = BeautifulSoup(driver.page_source, 'html.parser')
start_position = str(soup).find("number_of_primers_") + len('number_of_primers_')
end_position = str(soup)[start_position:].find('">') + start_position
ID = str(soup)[start_position:end_position]
print('--Open Web finish')
# IDs
# texts
Result1s = []
Arrs = []
Result2s = []
Self_dimers = []
Cross_Primer_dimers = []
Dimers = []

running_num = len(texts)

print('--Thermo uploading ...')

for text_num in range(running_num) :
    print('--'+str(text_num+1)+'/'+str(running_num))
    text = texts[text_num]
    
    driver.find_element_by_id("primers_"+ID).clear()
    driver.find_element_by_id("primers_"+ID).send_keys(text)
    sleep(1)

    result1 = searching('results_for_primer_tab_date_fmat_')
    result2 = searching('primers_dimer_detection_')

    Result1s.append(result1)
    Arr = []
    arr = result1.split('\n')
    if Thermo_mode == 1:
        stop_num = 7
    else:
        stop_num = 8
    for each in range(1,stop_num):
        arr2 = arr[each].split('\t')
        for each_ans in arr2[1:] :
            Arr.append( each_ans.replace(' ','') )
    Arrs.append(Arr) 
    Result2s.append(result2)

    Separate_point = result2.find('Cross Primer Dimers:')
    dimer_check_text1 = result2[:Separate_point]
    dimer_check_text2 = result2[Separate_point:]
    
    Self_dimer = dimer_check_text1.count('|')
    Cross_Primer_dimer = dimer_check_text2.count('|')
    Dimer = Self_dimer + Cross_Primer_dimer

    Self_dimers.append(Self_dimer)
    Cross_Primer_dimers.append(Cross_Primer_dimer)
    Dimers.append(Dimer)

driver.quit()

Ans = pd.DataFrame([IDs,texts,Result1s,Result2s,Self_dimers,Cross_Primer_dimers,Dimers],index=['ID','Sequence','Results_for_primer_tab_date_fmat','Primers_dimer_detection','Self_dimer','Cross_Primer_dimer','All_Dimer']).T
Ans2 = pd.DataFrame(Arrs,columns=columns,index=IDs[:running_num])

if Thermo_mode == 1:
    Ans.to_csv(now_path+'Results_for_dimers.csv',encoding='utf-8')
    Ans2.to_csv(now_path+'Results_for_primers.csv',encoding='utf-8')
else:
    Ans.to_csv(now_path+'Results_for_dimers_TFO.csv',encoding='utf-8')
    Ans2.to_csv(now_path+'Results_for_primers_TFO.csv',encoding='utf-8')
print('--Thermo finish')