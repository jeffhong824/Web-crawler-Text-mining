from docx import Document
from docx.shared import Inches
from docx.shared import RGBColor
from docx.enum.text import WD_COLOR_INDEX
from pandas import DataFrame,read_csv
import subprocess
import cv2
import os
import sys

def reversed_complemented(Seq):
    Seq_ = Seq[::-1]
    Seq_ = Seq_.replace('T','1');Seq_ = Seq_.replace('A','2');Seq_ = Seq_.replace('G','3');Seq_ = Seq_.replace('C','4');
    Seq_ = Seq_.replace('1','A');Seq_ = Seq_.replace('2','T');Seq_ = Seq_.replace('3','C');Seq_ = Seq_.replace('4','G');    
    return Seq_
    
def run(output_data_path,Target,F3,B3,F2,F1c,B2,B1c,LF,LB,TFO):
    
    # 打開word應用程式
    document = Document()
    
    Combined_case = []
    Combined_case_time = []
    String_all = ''
    
    ## 標準化 位置查找
    F3_start = Target.upper().find(F3.upper());F3_end = F3_start+len(F3);
    B3_start = Target.upper().find(B3.upper());B3_end = B3_start+len(B3);
    F2_start = Target.upper().find(F2.upper());F2_end = F2_start+len(F2);
    F1c_start = Target.upper().find(F1c.upper());F1c_end = F1c_start+len(F1c);
    B2_start = Target.upper().find(B2.upper());B2_end = B2_start+len(B2);
    B1c_start = Target.upper().find(B1c.upper());B1c_end = B1c_start+len(B1c);
    LF_start = Target.upper().find(LF.upper());LF_end = LF_start+len(LF);
    LFc = False
    if LF_start == -1 :
        LF_ = reversed_complemented(LF)
        LF_start = Target.upper().find(LF_.upper());LF_end = LF_start+len(LF_);
        LFc = True
    LB_start = Target.upper().find(LB.upper());LB_end = LB_start+len(LB);
    LBc = False
    if LB_start == -1 :
        LB_ = reversed_complemented(LB)
        LB_start = Target.upper().find(LB_.upper());LB_end = LB_start+len(LB_);
        LBc = True
    TFO_start = Target.upper().find(TFO.upper());TFO_end = TFO_start+len(TFO);
    
    # 防呆
    if F3_start==-1 or B3_start==-1 or F2_start==-1 or F1c_start==-1 or B2_start==-1 or B1c_start==-1 or LF_start==-1 or LB_start==-1 or TFO_start==-1 :
        print('!!!!')
        print(F3_start)
        print(B3_start)
        print(F2_start)
        print(F1c_start)
        print(B2_start)
        print(B1c_start)
        print(LF_start)
        print(LB_start)
        print(TFO_start)
        print(TFO)
        print(Target)
    position  = [[F3_start+1,F3_end],[B3_start+1,B3_end],[F2_start+1,F2_end],[F1c_start+1,F1c_end],[B2_start+1,B2_end],[B1c_start+1,B1c_end],[LF_start+1,LF_end],[LB_start+1,LB_end],[TFO_start+1,TFO_end]]
    
    ## 作圖
    # Title
    #document.add_heading(Group_name, 0)
    #document.add_heading('TTS-LAMP position', level=1)
    #document.add_paragraph('TTS-LAMP gene sequence label', style='Intense Quote')
    # print
    paragraph_F3 = document.add_paragraph('', style='List Bullet')
    F3_word = paragraph_F3.add_run('F3')
    F3_word.font.highlight_color = WD_COLOR_INDEX.BRIGHT_GREEN
    F3_word = paragraph_F3.add_run('  ')
    F3_word = paragraph_F3.add_run(F3)
    F3_word.font.highlight_color = WD_COLOR_INDEX.BRIGHT_GREEN

    paragraph_F2 = document.add_paragraph('', style='List Bullet')
    F2_word = paragraph_F2.add_run('F2')
    F2_word.font.highlight_color = WD_COLOR_INDEX.GRAY_25
    F2_word = paragraph_F2.add_run('  ')
    F2_word = paragraph_F2.add_run(F2)
    F2_word.font.highlight_color = WD_COLOR_INDEX.GRAY_25
    
    paragraph_F1 = document.add_paragraph('', style='List Bullet')
    F1_word = paragraph_F1.add_run('F1')
    F1_word.font.highlight_color = WD_COLOR_INDEX.YELLOW
    F1_word = paragraph_F1.add_run('  ')
    F1_word = paragraph_F1.add_run(F1c)
    F1_word.font.highlight_color = WD_COLOR_INDEX.YELLOW

    paragraph_B1c = document.add_paragraph('', style='List Bullet')
    B1c_word = paragraph_B1c.add_run('B1c')
    B1c_word.font.highlight_color = WD_COLOR_INDEX.TURQUOISE
    B1c_word = paragraph_B1c.add_run('  ')
    B1c_word = paragraph_B1c.add_run(B1c)
    B1c_word.font.highlight_color = WD_COLOR_INDEX.TURQUOISE
    
    paragraph_B2c = document.add_paragraph('', style='List Bullet')
    B2c_word = paragraph_B2c.add_run('B2c')
    B2c_word.font.highlight_color = WD_COLOR_INDEX.PINK
    B2c_word = paragraph_B2c.add_run('  ')
    B2c_word = paragraph_B2c.add_run(B2)
    B2c_word.font.highlight_color = WD_COLOR_INDEX.PINK
    
    paragraph_B3c = document.add_paragraph('', style='List Bullet')
    B3c_word = paragraph_B3c.add_run('B3c')
    B3c_word.font.highlight_color = WD_COLOR_INDEX.RED
    B3c_word = paragraph_B3c.add_run('  ')
    B3c_word = paragraph_B3c.add_run(B3)
    B3c_word.font.highlight_color = WD_COLOR_INDEX.RED
    
    if LFc :
        paragraph_LFc = document.add_paragraph('', style='List Bullet')
        LFc_word = paragraph_LFc.add_run('LFc')
        LFc_word.font.color.rgb = RGBColor(0, 255, 0)
        LFc_word = paragraph_LFc.add_run('  ')
        LFc_word = paragraph_LFc.add_run(LF_)
        LFc_word.font.color.rgb = RGBColor(0, 255, 0)
    else:
        paragraph_LF = document.add_paragraph('', style='List Bullet')
        LF_word = paragraph_LF.add_run('LF')
        LF_word.font.color.rgb = RGBColor(0, 255, 0)
        LF_word = paragraph_LF.add_run('  ')
        LF_word = paragraph_LF.add_run(LF)
        LF_word.font.color.rgb = RGBColor(0, 255, 0)
    if LBc :
        paragraph_LBc = document.add_paragraph('', style='List Bullet')
        LBc_word = paragraph_LBc.add_run('LBc ')
        LBc_word.font.color.rgb = RGBColor(0, 0, 255)
        LBc_word = paragraph_LBc.add_run('  ')
        LBc_word = paragraph_LBc.add_run(LB_)
        LBc_word.font.color.rgb = RGBColor(0, 0, 255)
    else:
        paragraph_LB = document.add_paragraph('', style='List Bullet')
        LB_word = paragraph_LB.add_run('LB')
        LB_word.font.color.rgb = RGBColor(0, 0, 255)
        LB_word = paragraph_LB.add_run('  ')
        LB_word = paragraph_LB.add_run(LB)
        LB_word.font.color.rgb = RGBColor(0, 0, 255)
    
    paragraph_TTS = document.add_paragraph('', style='List Bullet')
    TTS_word = paragraph_TTS.add_run('TTS')
    TTS_word.bold = True
    TTS_word.italic = True 
    #TTS_word.underline = True
    TTS_word.font.color.rgb = RGBColor(255, 0, 0)
    TTS_word = paragraph_TTS.add_run('  ')
    TTS_word = paragraph_TTS.add_run(TFO)
    TTS_word.bold = True
    TTS_word.italic = True 
    #TTS_word.underline = True
    TTS_word.font.color.rgb = RGBColor(255, 0, 0)
    
    ## 交集情況
    #document.add_paragraph('TTS-LAMP gene sequence location', style='Intense Quote')
    overlap = ''
    overlap_time = 0
    paragraph_Oli_each_word = document.add_paragraph('')
    for each_word in range(len(Target)) :
        Time = 0
        word = '0'
        color = ''
        word_color = '30'
        
        
        Oli_each_word = paragraph_Oli_each_word.add_run(Target[each_word])
        
        if F3_start <= each_word < F3_end :
            Time += 1
            color = '47'
            str_before = '\033[0;30;47m'
            str_after = '\033[0m'
            Oli_each_word.font.highlight_color = WD_COLOR_INDEX.BRIGHT_GREEN
        if B3_start <= each_word < B3_end :
            Time += 1
            color = '42'
            str_before = '\033[0;30;42m'
            str_after = '\033[0m'
            Oli_each_word.font.highlight_color = WD_COLOR_INDEX.RED
        if F2_start <= each_word < F2_end :
            Time += 1
            color = '43'
            str_before = '\033[0;30;43m'
            str_after = '\033[0m'
            Oli_each_word.font.highlight_color = WD_COLOR_INDEX.GRAY_25
        if F1c_start <= each_word < F1c_end :
            Time += 1
            color = '44'
            str_before = '\033[0;30;44m'
            str_after = '\033[0m'
            Oli_each_word.font.highlight_color = WD_COLOR_INDEX.YELLOW
        if B2_start <= each_word < B2_end :
            Time += 1
            color = '45'
            str_before = '\033[0;30;45m'
            str_after = '\033[0m'
            Oli_each_word.font.highlight_color = WD_COLOR_INDEX.PINK
        if B1c_start <= each_word < B1c_end :
            Time += 1
            color = '46'
            str_before = '\033[0;30;46m'
            str_after = '\033[0m'
            Oli_each_word.font.highlight_color = WD_COLOR_INDEX.TURQUOISE
        if LF_start <= each_word < LF_end :
            Time += 1
            word = '1'
            case_word = 'LF'
            word_color = '34'
            str_before = '\033[1;34m'
            str_after = '\033[0m'
            Oli_each_word.font.color.rgb = RGBColor(0, 255, 0)
        if LB_start <= each_word < LB_end :
            Time += 1
            word = '1'
            case_word = 'LB'
            word_color = '33'
            str_before = '\033[1;33m'
            str_after = '\033[0m'
            Oli_each_word.font.color.rgb = RGBColor(0, 0, 255)
        if TFO_start <= each_word < TFO_end :
            Time += 1
            word_color = '31'
            str_before = '\033[0;31m'
            str_after = '\033[0m'
            
            Oli_each_word.bold = True
            Oli_each_word.italic = True
            Oli_each_word.font.color.rgb = RGBColor(255, 0, 0)
        if Time > 1 :
            pre = ''
            if color != '':
                pre = ';'
            str_before = '\033[4;31'+pre+color+'m'
            str_after = '\033[0m'     

            Case = []

            if color == '47' :
                Case.append('F3')
            if color == '42' :
                Case.append('B3c')
            if color == '43' :
                Case.append('F2')
            if color == '44' :
                Case.append('F1')
            if color == '45' :
                Case.append('B2c')
            if color == '46' :
                Case.append('B1c')
            if word == '1' and case_word == 'LF' :
                Case.append('LF')
            if word == '1' and case_word == 'LB' :
                Case.append('LB')
            if word_color == '31':
                Case.append('TTS') 
                overlap += Target[each_word]
                overlap_time += 1
                Oli_each_word.underline = True

            if Case not in Combined_case :
                Combined_case.append(Case)
                Combined_case_time.append(1)
            else :
                Combined_case_time[Combined_case.index(Case)] += 1
        elif Time ==0 :
            str_before = ''
            str_after = ''

        print(str_before + Target[each_word] + str_after ,end = '') 
        String_all += str_before + Target[each_word] + str_after # 每個字的顏色
    
    paragraph_space = document.add_paragraph('\n')
    
    # Overlap
    #document.add_heading('TTS-LAMP position', level=1)
    Position = DataFrame(position,index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TTS'],columns=['Start','End'])
    TFO_overlap = overlap
    TFO_overlap_times = overlap_time
    
    LF_2_seq = LF
    LB_2_seq = LB
    LF_text = 'LF'
    LB_text = 'LB'
    if LFc :
        LF_2_seq = reversed_complemented(LF)
        LF_text = 'LFc'
    if LBc :
        LB_2_seq = reversed_complemented(LB)
        LB_text = 'LBc'

    TFO_LAMP = DataFrame( [ [F3,'F3',F3],[B3,'B3c',B3c],[F2,'F2',F2],[F1c,'F1',F1],[B2,'B2c',B2c],[B1c,'B1c',B1c],[LF,LF_text,LF_2_seq],[LB,LB_text,LB_2_seq],[TTS,'TTS',TTS] ],columns=['LAMP experiment','Label','Sequence'],index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TTS'])
    TFO_LAMP_all = TFO_LAMP.merge(Position, how='inner', left_index=True, right_index=True)
    print(position)
    '''
    document.add_paragraph('The TTS overlap part', style='Intense Quote')

    time_in_Combined_case = 0
    all_Combined_case = 0
    TFO_overlap_eachs = ''
    for each_case in Combined_case :
        TFO_overlap_each = TFO_overlap[all_Combined_case:all_Combined_case+int(Combined_case_time[time_in_Combined_case])]
        paragraph_overlap = document.add_paragraph('')
        over_lap_time = 0
        for each_case_words in each_case :
            Oli_each_word = paragraph_overlap.add_run(each_case_words)
            if over_lap_time != len(each_case)-1 :
                Oli_each_word = paragraph_overlap.add_run(',')
                over_lap_time += 1
                
        Oli_each_word = paragraph_overlap.add_run(' : '+str(Combined_case_time[time_in_Combined_case])+' mer - '+TFO_overlap_each+'\n')
        
        all_Combined_case += int(Combined_case_time[time_in_Combined_case])
        time_in_Combined_case += 1
        if time_in_Combined_case != len(Combined_case) :
            TFO_overlap_eachs += TFO_overlap_each + '-'
        else:
            TFO_overlap_eachs += TFO_overlap_each

    Oli_each_word = paragraph_overlap.add_run('TTS overlap '+str(TFO_overlap_times)+' mer : '+TFO_overlap)
    '''
    document.save(output_data_path)

    return TFO_LAMP_all,Combined_case,Combined_case_time,overlap,overlap_time

# doc2pdf_linux
def doc2_linux(doc,to_type):
    """
    convert a doc/docx document to pdf format (linux only, requires libreoffice)
    :param doc: path to document
    """
    cmd_part = 'libreoffice --convert-to '+to_type
    cmd = cmd_part.split() + [doc]
    p = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    p.wait(timeout=10)
    stdout, stderr = p.communicate()
    if stderr:
        raise subprocess.SubprocessError(stderr)
    
if __name__ == '__main__':

    # 輸入
    fasta_path = sys.argv[1] #'fasta_input_ver2/'
    merge_path = sys.argv[2] #'merge.csv'
    Data = read_csv(merge_path)
    output_path = sys.argv[3] #'visualization/'         
    if not os.path.isdir(output_path):
        os.mkdir(output_path)
    
    # 執行    
    for each_row in range(len(Data)): #len(Data)
        # input
        ID_ = Data.loc[each_row]['ID']
        Start = ID_.find('No')+2
        End = ID_.find('_')
        Number = ID_[Start:End]
        for root, dirs, files in os.walk(fasta_path):
            for each_paper in files :
                start = each_paper.find('tfo_no_')+len('tfo_no_')
                end = each_paper.find('___')
                if( int(each_paper[start:end])==int(Number) ):
                    with open(fasta_path+each_paper,'r') as fasta_file :
                        data = fasta_file.read()
                        Oli = data[data.find('\n')+1:].upper().replace('\n','')
                        break
        F3 = Data.loc[each_row]['F3_Sequence']
        B3 = Data.loc[each_row]['B3_Sequence']
        F2 = Data.loc[each_row]['F2_Sequence']
        F1c = Data.loc[each_row]['F1c_Sequence']
        B2 = Data.loc[each_row]['B2_Sequence']
        B1c = Data.loc[each_row]['B1c_Sequence']
        LF = Data.loc[each_row]['LF_Sequence']
        LB = Data.loc[each_row]['LB_Sequence']
        TTS = Data.loc[each_row]['TTS_Sequence']

        '''
        Oli =  'GATTGTTTCGCCAATGAAGACATATTCTTCTGCGCCAGCTTTGAAATCAAAAGAAGTATTAGCACAAGAGCAAGCTGTTAGTCAAGCAGCAGCTAATGAACAGGTATCAACAGCTCCTGTGAAGTCGATTACTTCAGAAGTTCCAGCAGCTAAAGAGGAAGTTAAACCAACTCAGACGTCAGTCAGTCAACAACAGTATCACCAGCTTCTGTTGCCGCTGAAACACCAGCTCCAGTAGCTAAAGTAGCACCGGTAAGAACTGTAGCAGCCCCTAGAGTGGCAAGTGTTAAAGTAGTCACTCCTAAAGTAGA'
        F3 = 'GCAAGCTGTTAGTCAAGC' 
        B3 = 'TGCTACAGTTCTTACCGG'
        F2 = 'AGCAGCTAATGAACAGGTATC'
        F1c = 'TCTTTAGCTGCTGGAACTTCTGAAG'
        B2 = 'TGCTACTTTAGCTACTGGAG'
        B1c= 'CAACTCAGACGTCAGTCAGTCA'
        LF = 'TCGACTTCACAGGAGCTGTT'
        LB = 'ACAACAGTATCACCAGCTTCTGT'
        TTS = 'AAAGAGGAAG'
        '''
        
        data_path = ID_
        output_data_path = output_path+data_path
        
        # output
        B3c = reversed_complemented(B3)
        B2c = reversed_complemented(B2)
        F1 = reversed_complemented(F1c)
        TFO_LAMP_all, Combined_case , Combined_case_time , TFO_overlap , TFO_overlap_times  = run(output_data_path+'.docx',Oli,F3,B3c,F2,F1,B2c,B1c,LF,LB,TTS)
        
        # change
        #doc2_linux(output_data_path+'.docx','pdf')
        doc2_linux(output_data_path+'.docx','png')
        
        img = cv2.imread(data_path+'.png')
        # 裁切區域的長度與寬度
        x = 100 # x座標
        y = 80  # y座標
        w = 625 # 寬
        h = 355 # 高
        # 裁切圖片
        crop_img = img[y:y+h, x:x+w]
        # 縮放
        crop_img = cv2.resize(crop_img, (w*2, h*2))
        # 覆蓋圖片
        cv2.imwrite(output_data_path+'.png', crop_img)

        try:
            os.remove(data_path+'.png')
        except OSError as e:
            print(e)
        else:
            print("File is deleted successfully")
            
        try:
            os.remove(output_data_path+'.docx')
        except OSError as e:
            print(e)
        else:
            print("File is deleted successfully")
            
        print('\n\n')
