class input_target_path() :
    
    def __init__(self, Top,TTS_result_path,LAMP_result_path,output_file_path,output_data_name):

        output_file_name = output_file_path+'TTS_LAMP_classification_'+output_data_name+'_top'+str(Top)
        Summary_detail_csv = output_file_path+'TTS_LAMP_classification_'+output_data_name+'_top'+str(Top)+'.csv'
        Summary_detail_report = output_file_path+'report_'+output_data_name+'_top'+str(Top)+'.html'
        
        from pandas import DataFrame,read_csv,read_excel
        from os import listdir,walk
        from os.path import isfile, isdir, join
        import os
        #import pandas_profiling
        
        now_path = os.getcwd() + '/'
        print('dir path : '+ now_path)


        def reversed_complemented(Seq):
            Seq_ = Seq[::-1]
            Seq_ = Seq_.replace('T','1');Seq_ = Seq_.replace('A','2');Seq_ = Seq_.replace('G','3');Seq_ = Seq_.replace('C','4');
            Seq_ = Seq_.replace('1','A');Seq_ = Seq_.replace('2','T');Seq_ = Seq_.replace('3','C');Seq_ = Seq_.replace('4','G');    
            return Seq_

        def run(Target,F3,B3,F2,F1c,B2,B1c,LF,LB,TFO):
            Combined_case = []
            Combined_case_time = []
            String_all = ''
            F3_start = Target.upper().find(F3.upper());F3_end = F3_start+len(F3);
            B3_start = Target.upper().find(B3.upper());B3_end = B3_start+len(B3);
            F2_start = Target.upper().find(F2.upper());F2_end = F2_start+len(F2);
            F1c_start = Target.upper().find(F1c.upper());F1c_end = F1c_start+len(F1c);
            B2_start = Target.upper().find(B2.upper());B2_end = B2_start+len(B2);
            B1c_start = Target.upper().find(B1c.upper());B1c_end = B1c_start+len(B1c);

            LF_start = Target.upper().find(LF.upper());LF_end = LF_start+len(LF);
            LFc = False
            if LF_start == -1 :
                LF_ = reversed_complemented(LF)
                LF_start = Target.upper().find(LF_.upper());LF_end = LF_start+len(LF_);
        #         print('LF-->',LF_)
                LFc = True
            LB_start = Target.upper().find(LB.upper());LB_end = LB_start+len(LB);
            LBc = False
            if LB_start == -1 :
                LB_ = reversed_complemented(LB)
                LB_start = Target.upper().find(LB_.upper());LB_end = LB_start+len(LB_);
        #         print('LB-->',LB_)
                LBc = True
            TFO_start = Target.upper().find(TFO.upper());TFO_end = TFO_start+len(TFO);
            '''
            print('\033[0;30;47mF3\033[0m','\033[0;30;47m'+F3+'\033[0m')
            print('\033[0;30;42mB3c\033[0m','\033[0;30;42m'+B3+'\033[0m')
            print('\033[0;30;43mF2\033[0m','\033[0;30;43m'+F2+'\033[0m')
            print('\033[0;30;44mF1\033[0m','\033[0;30;44m'+F1c+'\033[0m')
            print('\033[0;30;45mB2c\033[0m','\033[0;30;45m'+B2+'\033[0m')
            print('\033[0;30;46mB1c\033[0m','\033[0;30;46m'+B1c+'\033[0m')
            print('\033[0;31mTTS\033[0m','\033[0;31m'+TFO+'\033[0m')      
            if LFc :
                print('\033[1;34mLFc\033[0m','\033[1;34m'+LF_+'\033[0m')
            else:
                print('\033[1;34mLF\033[0m','\033[1;34m'+LF+'\033[0m')
            if LBc :
                print('\033[1;33mLBc\033[0m','\033[1;33m'+LB_+'\033[0m')
            else:
                print('\033[1;33mLB\033[0m','\033[1;33m'+LB+'\033[0m')
            print('\n')
            '''

            if F3_start==-1 or B3_start==-1 or F2_start==-1 or F1c_start==-1 or B2_start==-1 or B1c_start==-1 or LF_start==-1 or LB_start==-1 or TFO_start==-1 :
                print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                print('<',Target)
                print(F3_start)
                print(B3_start)
                print(F2_start)
                print(F1c_start)
                print(B2_start)
                print(B1c_start)
                print(LF_start)
                print(LB_start)
                print(TFO_start)
                print(TFO)
            position  = [[F3_start+1,F3_end],[B3_start+1,B3_end],[F2_start+1,F2_end],[F1c_start+1,F1c_end],[B2_start+1,B2_end],[B1c_start+1,B1c_end],[LF_start+1,LF_end],[LB_start+1,LB_end],[TFO_start+1,TFO_end]]

            overlap = ''
            overlap_time = 0

            for each_word in range(len(Target)) :
                Time = 0
                word = '0'
                color = ''
                word_color = '30'
                if F3_start <= each_word < F3_end :
                    Time += 1
                    color = '47'
                    str_before = '\033[0;30;47m'
                    str_after = '\033[0m'
                if B3_start <= each_word < B3_end :
                    Time += 1
                    color = '42'
                    str_before = '\033[0;30;42m'
                    str_after = '\033[0m'
                if F2_start <= each_word < F2_end :
                    Time += 1
                    color = '43'
                    str_before = '\033[0;30;43m'
                    str_after = '\033[0m'
                if F1c_start <= each_word < F1c_end :
                    Time += 1
                    color = '44'
                    str_before = '\033[0;30;44m'
                    str_after = '\033[0m'
                if B2_start <= each_word < B2_end :
                    Time += 1
                    color = '45'
                    str_before = '\033[0;30;45m'
                    str_after = '\033[0m'
                if B1c_start <= each_word < B1c_end :
                    Time += 1
                    color = '46'
                    str_before = '\033[0;30;46m'
                    str_after = '\033[0m'
                if LF_start <= each_word < LF_end :
                    Time += 1
                    word = '1'
                    case_word = 'LF'
                    word_color = '34'
                    str_before = '\033[1;34m'
                    str_after = '\033[0m'
                if LB_start <= each_word < LB_end :
                    Time += 1
                    word = '1'
                    case_word = 'LB'
                    word_color = '33'
                    str_before = '\033[1;33m'
                    str_after = '\033[0m'
                if TFO_start <= each_word < TFO_end :
                    Time += 1
                    word_color = '31'
                    str_before = '\033[0;31m'
                    str_after = '\033[0m'
                if Time > 1 :
                    pre = ''
                    if color != '':
                        pre = ';'
                    str_before = '\033[4;31'+pre+color+'m'
                    str_after = '\033[0m'     

                    Case = []

                    if color == '47' :
                        Case.append('F3')
                    if color == '42' :
                        Case.append('B3c')
                    if color == '43' :
                        Case.append('F2')
                    if color == '44' :
                        Case.append('F1')
                    if color == '45' :
                        Case.append('B2c')
                    if color == '46' :
                        Case.append('B1c')
                    if word == '1' and case_word == 'LF' :
                        Case.append('LF')
                    if word == '1' and case_word == 'LB' :
                        Case.append('LB')
                    if word_color == '31':
                        Case.append('TTS') 
                        overlap += Target[each_word]
                        overlap_time += 1

                    if Case not in Combined_case :
                        Combined_case.append(Case)
                        Combined_case_time.append(1)
                    else :
                        Combined_case_time[Combined_case.index(Case)] += 1
                elif Time ==0 :
                    str_before = ''
                    str_after = ''

                #print(str_before + Target[each_word] + str_after ,end = '')
                String_all += str_before + Target[each_word] + str_after

            #print('\n\n')
            return Combined_case,DataFrame(position,index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TTS'],columns=['Start','End']),Combined_case,LFc,LBc,overlap,overlap_time,Combined_case_time

        print('now : ',now_path+LAMP_result_path)
        
        
        Collect_target = []
        Collect_target_dGs = []
        for root, dirs, files in walk(now_path+LAMP_result_path):
            for file in files :
                if file.find('Final_Group') != -1 :
                    Final_Group = file
                    #print(Final_Group)
                    Collect_target_dG = []
                    
                    with open(now_path+LAMP_result_path+Final_Group,'r') as file :
                        All_Targets = file.read()
                        print(All_Targets)

                        Wanted = All_Targets.split('\n')
        
                        for each in range(len(Wanted)):
                            if each%6 ==0 :
                                if Wanted[each] != '':
                                    Collect_target.append(Wanted[each].replace(':','').replace(' ',''))
                                    search_line = Wanted[each].replace(' ','')
                                    search_line_Group = search_line[search_line.find('Group'):]
                                    Collect_target_dG.append(search_line_Group)
                                    
                    target_dir_path = Final_Group.replace('Final_Group_','').replace('.txt','') + '_PrimerList'
                    target_dG_file = Final_Group.replace('Final_Group_','').replace('.txt','') + '_Dimer_minimum_dG.txt'

                    with open(now_path+LAMP_result_path+target_dir_path+'/'+target_dG_file,'r') as target_dG_file_open :
                        Data_dG = target_dG_file_open.read()

                    print(Collect_target_dG)
                    for each_group in Collect_target_dG :
                        dG_from = Data_dG.find(each_group)+len(each_group)+18
                        dG_end = Data_dG[dG_from:].find('\n')+dG_from
                        Collect_target_dGs.append(Data_dG[dG_from:dG_end])
        # Collect_target

        print(len(Collect_target))
        print(Collect_target)

        Start_End_Score = []
        for each_collect in Collect_target :
            mid = each_collect.find('_to_')
            mid2 = each_collect.find('_score_')+len('_score_')
            
            
            Start = int(each_collect[each_collect[:mid].rfind('_')+1:mid])
            End = int(each_collect[mid+4:mid+4+each_collect[mid+4:].find('_')])
            Score = int(each_collect[mid2:mid2+each_collect[mid2:].find('_')])
            '''
            Start = int(each_collect[each_collect.find(String_start)+len(String_start) : each_collect.find('_to_')])
            End = int(each_collect[each_collect.find('_to_')+len('_to_') : each_collect.find('_score_')])
            Score = int(each_collect[each_collect.find('_score_')+len('_score_') : each_collect.find('_ : G')])
            '''
            Start_End_Score.append([Start,End,Score])

        TFO_seq = read_csv(TTS_result_path)
        Raw_TFO_Start_End_Score = []
        for order in range(len(TFO_seq)):
            Raw_TFO_Start_End_Score.append([int(TFO_seq.loc[order]['Start']),int(TFO_seq.loc[order]['End']),int(TFO_seq.loc[order]['Score'])])

        TFO_sequence = []
        No = []
        for finding in range(len(Start_End_Score)) : 
            TFO_order = Raw_TFO_Start_End_Score.index(Start_End_Score[finding])
            No.append(TFO_order+1)
        #     print('No.'+str(TFO_order+1),end='\t')
            TFO_sequence.append(TFO_seq.loc[TFO_order]['TTS'])
        #     print(TFO_seq.loc[TFO_order]['TTS'])

        def Run():
            These_case = []
            These_case_overlap = []
            These_case_overlap_A = []
            These_case_overlap_Bubble = []
            These_case_overlap_C = []
            These_case_overlap_D = []
            These_case_overlap_tfo = []
            These_case_overlap_tfo_times = []
            These_case_statues = []
            These_case_TFO_length = []

            These_case_F3_len = []
            These_case_B3_len = []
            These_case_F2_len = []
            These_case_F1c_len = []
            These_case_B2_len = []
            These_case_B1c_len = []
            These_case_LF_len = []
            These_case_LB_len = []

            These_case_TFO_GCrate = []
            These_case_F3_GCrate = []
            These_case_B3_GCrate = []
            These_case_F2_GCrate = []
            These_case_F1c_GCrate = []
            These_case_B2_GCrate = []
            These_case_B1c_GCrate = []
            These_case_LF_GCrate = []
            These_case_LB_GCrate = []    

            These_case_F3_Tm = []
            These_case_B3_Tm = []
            These_case_F2_Tm = []
            These_case_F1c_Tm = []
            These_case_B2_Tm = []
            These_case_B1c_Tm = []
            These_case_LF_Tm = []
            These_case_LB_Tm = []      

            These_case_F3_5_dG = []
            These_case_B3_5_dG = []
            These_case_F2_5_dG = []
            These_case_F1c_5_dG = []
            These_case_B2_5_dG = []
            These_case_B1c_5_dG = []
            These_case_LF_5_dG = []
            These_case_LB_5_dG = [] 

            These_case_F3_3_dG = []
            These_case_B3_3_dG = []
            These_case_F2_3_dG = []
            These_case_F1c_3_dG = []
            These_case_B2_3_dG = []
            These_case_B1c_3_dG = []
            These_case_LF_3_dG = []
            These_case_LB_3_dG = []   

            These_case_TFO_Sequence = []
            These_case_F3_Sequence = []
            These_case_B3_Sequence = []
            These_case_F2_Sequence = []
            These_case_F1c_Sequence = []
            These_case_B2_Sequence = []
            These_case_B1c_Sequence = []
            These_case_FIP_Sequence = []
            These_case_BIP_Sequence = [] 
            These_case_LF_Sequence = []
            These_case_LB_Sequence = []  
            
            These_case_inner_min_dG = []

            Target_dir_lists = []
            for root, dirs, files in walk(now_path+LAMP_result_path):
                for dirr in dirs :
                    Target_dir_lists.append(dirr)
            for num in range(len(Collect_target)):

                #print('\033[7;30;43m\t\t\t\tNo'+str(No[num])+'--'+Collect_target[num].replace('tfo','tts')+'\t\t\t\t\033[0m')
                #print('\n')
                Oli='';F3='';B3='';F2='';F1c='';B2='';B1c='';LF='';LB='';TFO='';
 
                #Path = LAMP_result_path+Collect_target[num][:Collect_target[num].find(' :')]+'_PrimerList/'
                #Group = Collect_target[num][Collect_target[num].find(' :')+3:]
                Group = Collect_target[num][Collect_target[num].rfind('_') : ]+'_'
                Noo_start = Collect_target[num].find('no_')
                Noo_end = Collect_target[num].find('___')+1
                Noo = Collect_target[num][Noo_start:Noo_end]
                print('\n\n')
                print(Collect_target[num])
                
                print('--Group : ',Group)
                for dirr in Target_dir_lists :
                    if dirr.find(Noo)!= -1 :
                        Path = dirr
                        break
                print('--Now : ',now_path+LAMP_result_path+Path)
                for root, dirs, files in walk(now_path+LAMP_result_path+Path):
                    for file in files :
                        #print(file)
                        if file.find(Noo)!= -1 and file.find(Group)!= -1 and file.find('csv')!= -1 :
                            File = file
                            print('--csv data : '+File)
                        elif file.find(Noo)!= -1 and file.find(Group.replace('_Group','_')[:-1]+'.')!= -1  and file.find('xls')== -1 and file.find('txt') == -1 and file.find('fa') != -1:
                            File2 = file
                            # file.find(Group.replace('_Group','_')[:-1]+'.')!= -1 and
                            print('--'+Collect_target[num])
                            print('--fasta data : '+File2)

                LFs_LBs = read_csv(now_path+LAMP_result_path+Path+'/'+File)

                LFs = []
                LF_lens = []
                LF_Tms = []
                LF_5_dGs = []
                LF_3_dGs = []
                LF_GCrates = []

                LBs = []
                LB_lens = []
                LB_Tms = []
                LB_5_dGs = []
                LB_3_dGs = []
                LB_GCrates = []

                for each_ in range(len(LFs_LBs)):
                    if (each_+1)%3 != 0 :
                        if LFs_LBs.loc[each_]['label'] == 'LF' : 
                            LFs.append(LFs_LBs.loc[each_]['Sequence'])
                            LF_lens.append(LFs_LBs.loc[each_]['len'])
                            LF_Tms.append(LFs_LBs.loc[each_]['Tm'])
                            LF_5_dGs.append(LFs_LBs.loc[each_]["5'dG"])
                            LF_3_dGs.append(LFs_LBs.loc[each_]["3'dG"])
                            LF_GCrates.append(LFs_LBs.loc[each_]['GCrate'])
                        else:
                            LBs.append(LFs_LBs.loc[each_]['Sequence'])
                            LB_lens.append(LFs_LBs.loc[each_]['len'])
                            LB_Tms.append(LFs_LBs.loc[each_]['Tm'])
                            LB_5_dGs.append(LFs_LBs.loc[each_]["5'dG"])
                            LB_3_dGs.append(LFs_LBs.loc[each_]["3'dG"])
                            LB_GCrates.append(LFs_LBs.loc[each_]['GCrate'])

                with open (now_path+LAMP_result_path+Path+'/'+File2,'r') as file2 :
                    Oli = file2.read()

                Olis = Oli.split('\n')
                Oli = Olis[2][6:]
                print('--'+Oli)

                TOP_path = now_path+LAMP_result_path+Path+'/'

                target_group_inner_primer = Group.replace('_Group','Primer_')
                for root, dirs, files in walk(TOP_path):
                    for file in files :
                #         print(file)
                        if file.find(target_group_inner_primer)!= -1 and file.find('Group')== -1 and file.find('xlsx')!= -1 : # and file.find(Collect_target[num][:Collect_target[num].find(' :')])!= -1
                            TOP_File = file
                            print('--Get Loop primer file : '+TOP_File)

                Inner_primer = TOP_path+TOP_File #Path+TOP_File.replace('~$','')

                primers = read_excel(Inner_primer,engine='openpyxl') #
                F3 = primers.loc[1]['Sequence'] 
                F3_len = primers.loc[1]['len']
                F3_Tm = primers.loc[1]['Tm']
                F3_5_dG = primers.loc[1]["5'dG"]
                F3_3_dG = primers.loc[1]["3'dG"]
                F3_GCrate = primers.loc[1]["GCrate"]

                B3_input = primers.loc[2]['Sequence']
                B3_len = primers.loc[2]['len']
                B3_Tm = primers.loc[2]['Tm']
                B3_5_dG = primers.loc[2]["5'dG"]
                B3_3_dG = primers.loc[2]["3'dG"]
                B3_GCrate = primers.loc[2]["GCrate"]
                B3c = reversed_complemented(B3_input)

                F2 = primers.loc[3]['Sequence']
                F2_len = primers.loc[3]['len']
                F2_Tm = primers.loc[3]['Tm']
                F2_5_dG = primers.loc[3]["5'dG"]
                F2_3_dG = primers.loc[3]["3'dG"]
                F2_GCrate = primers.loc[3]["GCrate"]        

                F1c_input = primers.loc[4]['Sequence']
                F1c_len = primers.loc[4]['len']
                F1c_Tm = primers.loc[4]['Tm']
                F1c_5_dG = primers.loc[4]["5'dG"]
                F1c_3_dG = primers.loc[4]["3'dG"]
                F1c_GCrate = primers.loc[4]["GCrate"]   
                F1 = reversed_complemented(F1c_input)

                B2_input = primers.loc[5]['Sequence']
                B2_len = primers.loc[5]['len']
                B2_Tm = primers.loc[5]['Tm']
                B2_5_dG = primers.loc[5]["5'dG"]
                B2_3_dG = primers.loc[5]["3'dG"]
                B2_GCrate = primers.loc[5]["GCrate"]  
                B2c = reversed_complemented(B2_input)


                B1c = primers.loc[6]['Sequence']
                B1c_len = primers.loc[6]['len']
                B1c_Tm = primers.loc[6]['Tm']
                B1c_5_dG = primers.loc[6]["5'dG"]
                B1c_3_dG = primers.loc[6]["3'dG"]
                B1c_GCrate = primers.loc[6]["GCrate"]         
                
                FIP = primers.loc[7]['Sequence']
                BIP = primers.loc[8]['Sequence']


                TFO = TFO_sequence[num]
                TFO_len = len(TFO)
                TFO_Tm = ''
                TFO_5_dG = ''
                TFO_3_dG = ''
                TFO_GCrate = '0.'+ str(int((TFO.count('G')+TFO.count('C')/len(TFO))*100))

                This_case = []
                This_case_overlap = []
                This_case_statues = []
                This_case_TFO_length = []

                try:
                    for running_LFLB in range(int(Top)): # top

                        LF = LFs[running_LFLB]
                        LF_len = LF_lens[running_LFLB]
                        LF_Tm = LF_Tms[running_LFLB]
                        LF_5_dG = LF_5_dGs[running_LFLB]
                        LF_3_dG = LF_3_dGs[running_LFLB]
                        LF_GCrate = LF_GCrates[running_LFLB]

                        LB = LBs[running_LFLB]
                        LB_len = LB_lens[running_LFLB]
                        LB_Tm = LB_Tms[running_LFLB]
                        LB_5_dG = LB_5_dGs[running_LFLB]
                        LB_3_dG = LB_3_dGs[running_LFLB]
                        LB_GCrate = LB_GCrates[running_LFLB]

                        This_case_TFO_length.append(len(TFO))
                        These_case_TFO_length.append(len(TFO))
                        #print('\033[7;30;43m\t\t\t\tNo'+str(No[num])+'_G'+Group.replace('Group','')+'_'+str(running_LFLB+1)+'\t\t\t\t\033[0m')

                        name_str = 'No'+str(No[num])+'_G'+Group.replace('Group','')+'_'+str(running_LFLB+1)
                        This_case.append(name_str)
                        These_case.append(name_str)

                        Mix , Position , Combined_case , LFc , LBc , TFO_overlap , TFO_overlap_times , Combined_case_time = run(Oli,F3,B3c,F2,F1,B2c,B1c,LF,LB,TFO)
                        LF_2_seq = LF
                        LB_2_seq = LB
                        LF_text = 'LF'
                        LB_text = 'LB'
                        if LFc :
                            LF_2_seq = reversed_complemented(LF)
                            LF_text = 'LFc'
                        if LBc :
                            LB_2_seq = reversed_complemented(LB)
                            LB_text = 'LBc'

                        TFO_LAMP = DataFrame( [ [F3,F3_len,F3_Tm,F3_5_dG,F3_3_dG,F3_GCrate,'F3',F3],[B3_input,B3_len,B3_Tm,B3_5_dG,B3_3_dG,B3_GCrate,'B3c',B3c],[F2,F2_len,F2_Tm,F2_5_dG,F2_3_dG,F2_GCrate,'F2',F2],[F1c_input,F1c_len,F1c_Tm,F1c_5_dG,F1c_3_dG,F1c_GCrate,'F1',F1],[B2_input,B2_len,B2_Tm,B2_5_dG,B2_3_dG,B2_GCrate,'B2c',B2c],[B1c,B1c_len,B1c_Tm,B1c_5_dG,B1c_3_dG,B1c_GCrate,'B1c',B1c],[LF,LF_len,LF_Tm,LF_5_dG,LF_3_dG,LF_GCrate,LF_text,LF_2_seq],[LB,LB_len,LB_Tm,LB_5_dG,LB_3_dG,LB_GCrate,LB_text,LB_2_seq],[TFO,TFO_len,TFO_Tm,TFO_5_dG,TFO_3_dG,TFO_GCrate,'TTS',TFO] ],columns=['LAMP experiment','len','Tm','5dG','3dG','GCrate','Label','Sequence'],index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TTS'])
                        These_case_F3_len.append(F3_len)
                        These_case_B3_len.append(B3_len)
                        These_case_F2_len.append(F2_len)
                        These_case_F1c_len.append(F1c_len)
                        These_case_B2_len.append(B2_len)
                        These_case_B1c_len.append(B1c_len)
                        These_case_LF_len.append(LF_len)
                        These_case_LB_len.append(LB_len)

                        These_case_TFO_GCrate.append(TFO_GCrate)
                        These_case_F3_GCrate.append(F3_GCrate)
                        These_case_B3_GCrate.append(B3_GCrate)
                        These_case_F2_GCrate.append(F2_GCrate)
                        These_case_F1c_GCrate.append(F1c_GCrate)
                        These_case_B2_GCrate.append(B2_GCrate)
                        These_case_B1c_GCrate.append(B1c_GCrate)
                        These_case_LF_GCrate.append(LF_GCrate)
                        These_case_LB_GCrate.append(LB_GCrate)   

                        These_case_F3_Tm.append(F3_Tm)
                        These_case_B3_Tm.append(B3_Tm)
                        These_case_F2_Tm.append(F2_Tm)
                        These_case_F1c_Tm.append(F1c_Tm)
                        These_case_B2_Tm.append(B2_Tm)
                        These_case_B1c_Tm.append(B1c_Tm)
                        These_case_LF_Tm.append(LF_Tm)
                        These_case_LB_Tm.append(LB_Tm)     

                        These_case_F3_5_dG.append(F3_5_dG)
                        These_case_B3_5_dG.append(B3_5_dG)
                        These_case_F2_5_dG.append(F2_5_dG)
                        These_case_F1c_5_dG.append(F1c_5_dG)
                        These_case_B2_5_dG.append(B2_5_dG)
                        These_case_B1c_5_dG.append(B1c_5_dG)
                        These_case_LF_5_dG.append(LF_5_dG)
                        These_case_LB_5_dG.append(LB_5_dG)

                        These_case_F3_3_dG.append(F3_3_dG)
                        These_case_B3_3_dG.append(B3_3_dG)
                        These_case_F2_3_dG.append(F2_3_dG)
                        These_case_F1c_3_dG.append(F1c_3_dG)
                        These_case_B2_3_dG.append(B2_3_dG)
                        These_case_B1c_3_dG.append(B1c_3_dG)
                        These_case_LF_3_dG.append(LF_3_dG)
                        These_case_LB_3_dG.append(LB_3_dG)   

                        These_case_TFO_Sequence.append(TFO)
                        These_case_F3_Sequence.append(F3)
                        These_case_B3_Sequence.append(B3_input)
                        These_case_F2_Sequence.append(F2)
                        These_case_F1c_Sequence.append(F1c_input)
                        These_case_B2_Sequence.append(B2_input)
                        These_case_B1c_Sequence.append(B1c)
                        These_case_FIP_Sequence.append(FIP)
                        These_case_BIP_Sequence.append(BIP)
                        These_case_LF_Sequence.append(LF)
                        These_case_LB_Sequence.append(LB) 

        #                 TFO_LAMP = DataFrame( [ [F3,'F3',F3],[B3_input,'B3c',B3c],[F2,'F2',F2],[F1c_input,'F1',F1],[B2_input,'B2c',B2c],[B1c,'B1c',B1c],[LF,LF_text,LF_2_seq],[LB,LB_text,LB_2_seq],[TFO,'TFO',TFO] ],columns=['LAMP experiment','Label','Sequence'],index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TFO'])    
        #                 print(TFO_LAMP)
        #                 print(Position)
                        TFO_LAMP_all = TFO_LAMP.merge(Position, how='inner', left_index=True, right_index=True)
                        #display(HTML(TFO_LAMP_all.to_html()))
                        #print('\n\nThe TTS overlap part is:')
                        time_in_Combined_case = 0
                        all_Combined_case = 0
                        TFO_overlap_eachs = ''
                        for each_case in Combined_case :
                            TFO_overlap_each = TFO_overlap[all_Combined_case:all_Combined_case+int(Combined_case_time[time_in_Combined_case])]
                            #print(each_case , Combined_case_time[time_in_Combined_case] , TFO_overlap_each)
                            all_Combined_case += int(Combined_case_time[time_in_Combined_case])
                            time_in_Combined_case += 1
                            if time_in_Combined_case != len(Combined_case) :
                                TFO_overlap_eachs += TFO_overlap_each + '-'
                            else:
                                TFO_overlap_eachs += TFO_overlap_each
                            
                        #print('TTS overlap '+str(TFO_overlap_times)+' mer : '+TFO_overlap)
                        #print('\n\n')

                        This_case_overlap.append(Combined_case)
                        These_case_overlap.append(Combined_case)
                        These_case_overlap_tfo.append(TFO_overlap_eachs)
                        These_case_overlap_tfo_times.append(TFO_overlap_times)

                        F3_position_start = Position.loc['F3']['Start']
                        F3_position_end = Position.loc['F3']['End']
                        B3c_position_start = Position.loc['B3']['Start']
                        B3c_position_end = Position.loc['B3']['End']
                        F2_position_start = Position.loc['F2']['Start']
                        F2_position_end = Position.loc['F2']['End']
                        F1_position_start = Position.loc['F1c']['Start']
                        F1_position_end = Position.loc['F1c']['End']
                        B2c_position_start = Position.loc['B2']['Start']
                        B2c_position_end = Position.loc['B2']['End']
                        B1c_position_start = Position.loc['B1c']['Start']
                        B1c_position_end = Position.loc['B1c']['End']
                        LF_position_start = Position.loc['LF']['Start']
                        LF_position_end = Position.loc['LF']['End']
                        LB_position_start = Position.loc['LB']['Start']
                        LB_position_end = Position.loc['LB']['End']
                        TFO_position_start = Position.loc['TTS']['Start']
                        TFO_position_end = Position.loc['TTS']['End']

                        CaseA = False
                        CaseBubble = False
                        CaseC = False
                        CaseD = False

                        # A
                        This_case_statues_ = []
                        This_case_overlap_ = 0
                        if Combined_case == [] and len(TFO) >= 10:
                            if F1_position_end<TFO_position_start and TFO_position_end<B1c_position_start:
                                #print('Case A1','TTS length : ',len(TFO))
                                This_case_statues_.append('A1')

                                CaseA = True
                                
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('F1' in each_case or 'B1c' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ += Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                
                                    
                            elif F2_position_end<TFO_position_start and TFO_position_end<B2c_position_start:
                                #print('Case A2','TTS length : ',len(TFO))
                                This_case_statues_.append('A2')

                                CaseA = True
                                
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('F1' in each_case or 'B1c' in each_case or 'F2' in each_case or 'B2c' in each_case) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ += Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
        #                     elif F3_position_end<TFO_position_start and TFO_position_end<B3c_position_start:
        #                         print('Case A3','TFO length : ',len(TFO))
        #                         This_case_statues_.append('A3')

        #                         CaseA = True
                        if CaseA :
                            These_case_overlap_A.append(This_case_overlap_)
                        else:
                            These_case_overlap_A.append(-1)
                        This_case_overlap_ = 0
                        
                        # Bubble
                        time_in_Combined_case_Bubble = 0
                        Pass_Bubble = True
        #                 if Combined_case != [] :
        #                     for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['F1', 'TFO'],['TFO','F1'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c']  ] :
        #                         if each_combine_fail in Combined_case :
        #                             Pass_C = False
        #                             break

                        if Pass_Bubble : 
                            if TFO_position_start-F2_position_end < 0 and TFO_position_end-F2_position_end > 0 : # FIP
                                This_case_statues_.append('Bubble_FIP')

                                CaseBubble = True
                                
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('F1' in each_case or 'F2' in each_case  ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ += Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_Bubble < This_case_overlap_ :
                                    time_in_Combined_case_Bubble = This_case_overlap_     
                                    This_case_overlap_ = 0
                            if TFO_position_start-LB_position_end <0 and TFO_position_end-LB_position_end > 0 : # LB 
                                This_case_statues_.append('Bubble_LB')

                                CaseBubble = True

                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('LB' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_Bubble < This_case_overlap_ :
                                    time_in_Combined_case_Bubble = This_case_overlap_     
                                    This_case_overlap_ = 0
                            if TFO_position_start-B2c_position_start <0 and TFO_position_end-B2c_position_start > 0 : # BIP
                                This_case_statues_.append('Bubble_BIP')

                                CaseBubble = True

                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('B2c' in each_case or 'B1c' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ += Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_Bubble < This_case_overlap_ :
                                    time_in_Combined_case_Bubble = This_case_overlap_   
                                    This_case_overlap_ = 0
                            if TFO_position_start-LF_position_start <0 and TFO_position_end-LF_position_start > 0 : # LF
                                This_case_statues_.append('Bubble_LF')

                                CaseBubble = True

                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('LF' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_Bubble < This_case_overlap_ :
                                    time_in_Combined_case_Bubble = This_case_overlap_  
                                    This_case_overlap_ = 0
                        if CaseBubble :
                            These_case_overlap_Bubble.append(time_in_Combined_case_Bubble)
                        else:
                            These_case_overlap_Bubble.append(-1)
                        This_case_overlap_ = 0
                        
                        # C
                        time_in_Combined_case_C = 0
                        Pass_C = True
        #                 if Combined_case != [] :
        #                     for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['F1', 'TFO'],['TFO','F1'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c']  ] :
        #                         if each_combine_fail in Combined_case :
        #                             Pass_C = False
        #                             break

                        if Pass_C : 
                            if TFO_position_start-LF_position_end <=1 and TFO_position_start-LF_position_start >= 0 : # LF behind
                                #print('Case C_LF')
                                This_case_statues_.append('C_LF')

                                CaseC = True
                                
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('LF' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_C < This_case_overlap_ :
                                    time_in_Combined_case_C = This_case_overlap_  
                                    This_case_overlap_ = 0
                            if TFO_position_end-LB_position_end <=0 and TFO_position_end-LB_position_start >= -1 : # LB infront
                                #print('Case C_LB')
                                This_case_statues_.append('C_LB')

                                CaseC = True

                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('LB' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_C < This_case_overlap_ :
                                    time_in_Combined_case_C = This_case_overlap_
                                    This_case_overlap_ = 0
                        if CaseC :
                            These_case_overlap_C.append(time_in_Combined_case_C)
                        else:
                            These_case_overlap_C.append(-1)
                        This_case_overlap_ = 0
                        # D
                        time_in_Combined_case_D = 0
                        if TFO_position_end-F2_position_end <=0 and TFO_position_end-F2_position_start >= -1 and TFO_position_start-F2_position_start <= 0 : # F2                  
                            Pass_D = True
        #                     if Combined_case != [] :
        #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F1', 'TFO'],['TFO','F1'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
        #                             if each_combine_fail in Combined_case :
        #                                 Pass_D = False
        #                                 break
                            if Pass_D:
                                #print('Case D_F2')
                                This_case_statues_.append('D_F2')

                                CaseD = True
                            
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('F2' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_D < This_case_overlap_ :
                                    time_in_Combined_case_D = This_case_overlap_
                                    This_case_overlap_ = 0
                        if TFO_position_end-F1_position_end <=0 and TFO_position_end-F1_position_start >= -1 and TFO_position_start-F1_position_start <= 0 : # F1                 
                            Pass_D = True
        #                     if Combined_case != [] :
        #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
        #                             if each_combine_fail in Combined_case :
        #                                 Pass_D = False
        #                                 break
                            if Pass_D:
                                #print('Case D_F1')
                                This_case_statues_.append('D_F1')

                                CaseD = True

                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('F1' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_D < This_case_overlap_ :
                                    time_in_Combined_case_D = This_case_overlap_
                                    This_case_overlap_ = 0
                        if TFO_position_start-B2c_position_end <=1 and TFO_position_start-B2c_position_start >= 0 and TFO_position_end-B2c_position_end >= 0 : # B2c                 
                            Pass_D = True
        #                     if Combined_case != [] :
        #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F1', 'TFO'],['TFO','F1'],['F2', 'TFO'],['TFO','F2'],['B1c', 'TFO'],['TFO','B1c'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
        #                             if each_combine_fail in Combined_case :
        #                                 Pass_D = False
        #                                 break
                            if Pass_D:
                                #print('Case D_B2c')
                                This_case_statues_.append('D_B2c')

                                CaseD = True
                            
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('B2c' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_D < This_case_overlap_ :
                                    time_in_Combined_case_D = This_case_overlap_
                                    This_case_overlap_ = 0
                        if TFO_position_start-B1c_position_end <=1 and TFO_position_start-B1c_position_start >= 0 and TFO_position_end-B1c_position_end >= 0 : # B1c                 
                            Pass_D = True
        #                     if Combined_case != [] :
        #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['B2c', 'TFO'],['TFO','B2c'],['F1', 'TFO'],['TFO','F1'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
        #                             if each_combine_fail in Combined_case :
        #                                 Pass_D = False
        #                                 break
                            if Pass_D:
                                #print('Case D_B1c')
                                This_case_statues_.append('D_B1c')

                                CaseD = True
            
                                time_in_Combined_case = 0
                                for each_case in Combined_case :
                                    if 'TTS' in each_case and ('B1c' in each_case ) :
                                        #print(each_case , Combined_case_time[time_in_Combined_case])
                                        This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                    time_in_Combined_case += 1
                                if time_in_Combined_case_D < This_case_overlap_ :
                                    time_in_Combined_case_D = This_case_overlap_
                                    This_case_overlap_ = 0
                        if CaseD :
                            These_case_overlap_D.append(time_in_Combined_case_D)
                        else:
                            These_case_overlap_D.append(-1)
                        This_case_overlap_ = 0
                        # Other
                        if CaseA == False and CaseBubble == False and CaseC == False and CaseD == False : 
                            #print('Other Case')
                            This_case_statues_.append('Other')

                        This_case_statues.append(This_case_statues_) 
                        These_case_statues.append(This_case_statues_)       
                        These_case_inner_min_dG.append(Collect_target_dGs[num])                        

        #                 Pass_C = True
        #                 Check_if_else_C = False
        #                 for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3', 'TFO'],['TFO','B3'],['F2', 'TFO'],['TFO','F2'],['F1c', 'TFO'],['TFO','F1c'],['B2', 'TFO'],['TFO','B2'],['B1c', 'TFO'],['TFO','B1c']  ] :
        #                     if Combined_case!= []:
        #                         if each_combine_fail in Combined_case :
        #                             Pass_C = False
        #                             break
        # #                 print(Pass_C)
        #                 if Pass_C :
        #                     if abs(TFO_position-LF_position_end) <= 10 or abs(TFO_position_end-LF_position_start) <= 10 or abs(TFO_position-LB_position_end) <= 10 or abs(TFO_position_end-LB_position_start) <= 10 :
        #                         print('Case C')
        #                         This_case_statues.append('C')
        #                         These_case_statues.append('C')
        #                         Check_if_else_C = True

        #                 if  Check_if_else_C == False:     
        #                     if TFO_position <= F2_position :
        #                         print('Case D')
        #                         This_case_statues.append('D')
        #                         These_case_statues.append('D')

        #                     elif (F3_position <= TFO_position and  TFO_position<= B3_position ) or (B3_position <= TFO_position and  TFO_position<= F3_position ) :
        #                         This_case_statues.append('A')
        #                         These_case_statues.append('A')

        #                     else :
        #                         print('Case Other')
        #                         This_case_statues.append('Other')
        #                         These_case_statues.append('Other')

                        #print('----------------------------------\n')

                except:
                    running_LFLB -= 1


                D = DataFrame([This_case_statues,This_case_overlap,This_case_TFO_length],columns=This_case,index=['Model type','Overlapping part','TTS length']).T
                #print(D)
                #print('\n\n\n\n\n\n')

            #print('Summary')
            Columns_ = [each for each in range(1,len(These_case)+1)]


            Result_1 = DataFrame([These_case,These_case_statues,These_case_overlap,These_case_overlap_tfo,These_case_overlap_tfo_times,These_case_overlap_A,These_case_overlap_Bubble,These_case_overlap_C,These_case_overlap_D,These_case_TFO_length] ,index=['ID','Model_type','Overlapping_part','TTS_overlap','TTS_overlap_mers','TTS_overlap_mers_A_max','TTS_overlap_mers_Bubble_max','TTS_overlap_mers_C_max','TTS_overlap_mers_D_max','TTS_length'],columns=Columns_).T 
            Result_2 = Result_2 = DataFrame([These_case,These_case_statues,These_case_overlap,These_case_overlap_tfo,These_case_overlap_tfo_times,These_case_overlap_A,These_case_overlap_Bubble,These_case_overlap_C,These_case_overlap_D,These_case_TFO_length,These_case_F3_len,These_case_B3_len,These_case_F2_len,These_case_F1c_len,These_case_B2_len,These_case_B1c_len,These_case_LF_len,These_case_LB_len,These_case_TFO_GCrate,These_case_F3_GCrate,These_case_B3_GCrate,These_case_F2_GCrate,These_case_F1c_GCrate,These_case_B2_GCrate,These_case_B1c_GCrate,These_case_LF_GCrate,These_case_LB_GCrate,These_case_F3_Tm,These_case_B3_Tm,These_case_F2_Tm,These_case_F1c_Tm,These_case_B2_Tm,These_case_B1c_Tm,These_case_LF_Tm,These_case_LB_Tm,These_case_F3_5_dG,These_case_B3_5_dG,These_case_F2_5_dG,These_case_F1c_5_dG,These_case_B2_5_dG,These_case_B1c_5_dG,These_case_LF_5_dG,These_case_LB_5_dG,These_case_F3_3_dG,These_case_B3_3_dG,These_case_F2_3_dG,These_case_F1c_3_dG,These_case_B2_3_dG,These_case_B1c_3_dG,These_case_LF_3_dG,These_case_LB_3_dG,These_case_inner_min_dG,These_case_TFO_Sequence,These_case_F3_Sequence,These_case_B3_Sequence,These_case_F2_Sequence,These_case_F1c_Sequence,These_case_B2_Sequence,These_case_B1c_Sequence,These_case_FIP_Sequence,These_case_BIP_Sequence,These_case_LF_Sequence,These_case_LB_Sequence] ,index=['ID','Model_type','Overlapping_part','TTS_overlap','TTS_overlap_mers','TTS_overlap_mers_A_max','TTS_overlap_mers_Bubble_max','TTS_overlap_mers_C_max','TTS_overlap_mers_D_max','TTS_length','F3_len','B3_len','F2_len','F1c_len','B2_len','B1c_len','LF_len','LB_len','TTS_GCrate','F3_GCrate','B3_GCrate','F2_GCrate','F1c_GCrate','B2_GCrate','B1c_GCrate','LF_GCrate','LB_GCrate','F3_Tm','B3_Tm','F2_Tm','F1c_Tm','B2_Tm','B1c_Tm','LF_Tm','LB_Tm','F3_5dG','B3_5dG','F2_5dG','F1c_5dG','B2_5dG','B1c_5dG','LF_5dG','LB_5dG','F3_3dG','B3_3dG','F2_3dG','F1c_3dG','B2_3dG','B1c_3dG','LF_3dG','LB_3dG','dimer_minimum_dG','TTS_Sequence','F3_Sequence','B3_Sequence','F2_Sequence','F1c_Sequence','B2_Sequence','B1c_Sequence','FIP_Sequence','BIP_Sequence','LF_Sequence','LB_Sequence' ],columns=Columns_).T 
            return Result_1,Result_2

        Summary,Summary_detail = Run()
        
        #exporter = HTMLExporter()
        #output_notebook = nbformat.read(notebook_name, as_version=4)

        #output, resources = exporter.from_notebook_node(output_notebook)
        #codecs.open(output_file_name+'.html', 'w', encoding='utf-8').write(output)
        
        Summary_detail.to_csv(Summary_detail_csv)
        Summary_detail = Summary_detail[list(Summary_detail.columns)[4:9]]
        #pfr = pandas_profiling.ProfileReport(Summary_detail)
        #pfr.to_file(Summary_detail_report)


class input_target_path_each() :
    
    def __init__(self, Top,TTS_result_path,LAMP_result_path,notebook_name,output_file_path,output_data_name,num):

        output_file_name = output_file_path+'TTS_LAMP_classification_'+output_data_name+'_top'+str(Top)
        Summary_detail_csv = output_file_path+'TTS_LAMP_classification_'+output_data_name+'_top'+str(Top)+'.csv'
        Summary_detail_report = output_file_path+'report_'+output_data_name+'_top'+str(Top)+'.html'
        
        from pandas import DataFrame,read_csv,read_excel
        from os import listdir,walk
        from os.path import isfile, isdir, join
        from IPython.display import display
        from IPython.core.display import HTML
        from nbconvert import HTMLExporter
        import codecs
        import nbformat
        import pandas_profiling
        import os
        
        now_path = os.getcwd() + '/'
        #print('dir path : '+ now_path)


        def reversed_complemented(Seq):
            Seq_ = Seq[::-1]
            Seq_ = Seq_.replace('T','1');Seq_ = Seq_.replace('A','2');Seq_ = Seq_.replace('G','3');Seq_ = Seq_.replace('C','4');
            Seq_ = Seq_.replace('1','A');Seq_ = Seq_.replace('2','T');Seq_ = Seq_.replace('3','C');Seq_ = Seq_.replace('4','G');    
            return Seq_

        def run(Target,F3,B3,F2,F1c,B2,B1c,LF,LB,TFO):
            Combined_case = []
            Combined_case_time = []
            String_all = ''
            F3_start = Target.upper().find(F3.upper());F3_end = F3_start+len(F3);
            B3_start = Target.upper().find(B3.upper());B3_end = B3_start+len(B3);
            F2_start = Target.upper().find(F2.upper());F2_end = F2_start+len(F2);
            F1c_start = Target.upper().find(F1c.upper());F1c_end = F1c_start+len(F1c);
            B2_start = Target.upper().find(B2.upper());B2_end = B2_start+len(B2);
            B1c_start = Target.upper().find(B1c.upper());B1c_end = B1c_start+len(B1c);

            LF_start = Target.upper().find(LF.upper());LF_end = LF_start+len(LF);
            LFc = False
            if LF_start == -1 :
                LF_ = reversed_complemented(LF)
                LF_start = Target.upper().find(LF_.upper());LF_end = LF_start+len(LF_);
        #         print('LF-->',LF_)
                LFc = True
            LB_start = Target.upper().find(LB.upper());LB_end = LB_start+len(LB);
            LBc = False
            if LB_start == -1 :
                LB_ = reversed_complemented(LB)
                LB_start = Target.upper().find(LB_.upper());LB_end = LB_start+len(LB_);
        #         print('LB-->',LB_)
                LBc = True
            TFO_start = Target.upper().find(TFO.upper());TFO_end = TFO_start+len(TFO);
            
            print('\033[0;30;47mF3\033[0m','\033[0;30;47m'+F3+'\033[0m')
            print('\033[0;30;42mB3c\033[0m','\033[0;30;42m'+B3+'\033[0m')
            print('\033[0;30;43mF2\033[0m','\033[0;30;43m'+F2+'\033[0m')
            print('\033[0;30;44mF1\033[0m','\033[0;30;44m'+F1c+'\033[0m')
            print('\033[0;30;45mB2c\033[0m','\033[0;30;45m'+B2+'\033[0m')
            print('\033[0;30;46mB1c\033[0m','\033[0;30;46m'+B1c+'\033[0m')
            print('\033[0;31mTTS\033[0m','\033[0;31m'+TFO+'\033[0m')      
            if LFc :
                print('\033[1;34mLFc\033[0m','\033[1;34m'+LF_+'\033[0m')
            else:
                print('\033[1;34mLF\033[0m','\033[1;34m'+LF+'\033[0m')
            if LBc :
                print('\033[1;33mLBc\033[0m','\033[1;33m'+LB_+'\033[0m')
            else:
                print('\033[1;33mLB\033[0m','\033[1;33m'+LB+'\033[0m')
            print('\n')
            

            if F3_start==-1 or B3_start==-1 or F2_start==-1 or F1c_start==-1 or B2_start==-1 or B1c_start==-1 or LF_start==-1 or LB_start==-1 or TFO_start==-1 :
                print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                print('<',Target)
                print(F3_start)
                print(B3_start)
                print(F2_start)
                print(F1c_start)
                print(B2_start)
                print(B1c_start)
                print(LF_start)
                print(LB_start)
                print(TFO_start)
                print(TFO)
            position  = [[F3_start+1,F3_end],[B3_start+1,B3_end],[F2_start+1,F2_end],[F1c_start+1,F1c_end],[B2_start+1,B2_end],[B1c_start+1,B1c_end],[LF_start+1,LF_end],[LB_start+1,LB_end],[TFO_start+1,TFO_end]]

            overlap = ''
            overlap_time = 0

            for each_word in range(len(Target)) :
                Time = 0
                word = '0'
                color = ''
                word_color = '30'
                if F3_start <= each_word < F3_end :
                    Time += 1
                    color = '47'
                    str_before = '\033[0;30;47m'
                    str_after = '\033[0m'
                if B3_start <= each_word < B3_end :
                    Time += 1
                    color = '42'
                    str_before = '\033[0;30;42m'
                    str_after = '\033[0m'
                if F2_start <= each_word < F2_end :
                    Time += 1
                    color = '43'
                    str_before = '\033[0;30;43m'
                    str_after = '\033[0m'
                if F1c_start <= each_word < F1c_end :
                    Time += 1
                    color = '44'
                    str_before = '\033[0;30;44m'
                    str_after = '\033[0m'
                if B2_start <= each_word < B2_end :
                    Time += 1
                    color = '45'
                    str_before = '\033[0;30;45m'
                    str_after = '\033[0m'
                if B1c_start <= each_word < B1c_end :
                    Time += 1
                    color = '46'
                    str_before = '\033[0;30;46m'
                    str_after = '\033[0m'
                if LF_start <= each_word < LF_end :
                    Time += 1
                    word = '1'
                    case_word = 'LF'
                    word_color = '34'
                    str_before = '\033[1;34m'
                    str_after = '\033[0m'
                if LB_start <= each_word < LB_end :
                    Time += 1
                    word = '1'
                    case_word = 'LB'
                    word_color = '33'
                    str_before = '\033[1;33m'
                    str_after = '\033[0m'
                if TFO_start <= each_word < TFO_end :
                    Time += 1
                    word_color = '31'
                    str_before = '\033[0;31m'
                    str_after = '\033[0m'
                if Time > 1 :
                    pre = ''
                    if color != '':
                        pre = ';'
                    str_before = '\033[4;31'+pre+color+'m'
                    str_after = '\033[0m'     

                    Case = []

                    if color == '47' :
                        Case.append('F3')
                    if color == '42' :
                        Case.append('B3c')
                    if color == '43' :
                        Case.append('F2')
                    if color == '44' :
                        Case.append('F1')
                    if color == '45' :
                        Case.append('B2c')
                    if color == '46' :
                        Case.append('B1c')
                    if word == '1' and case_word == 'LF' :
                        Case.append('LF')
                    if word == '1' and case_word == 'LB' :
                        Case.append('LB')
                    if word_color == '31':
                        Case.append('TTS') 
                        overlap += Target[each_word]
                        overlap_time += 1

                    if Case not in Combined_case :
                        Combined_case.append(Case)
                        Combined_case_time.append(1)
                    else :
                        Combined_case_time[Combined_case.index(Case)] += 1
                elif Time ==0 :
                    str_before = ''
                    str_after = ''

                print(str_before + Target[each_word] + str_after ,end = '') # show
                String_all += str_before + Target[each_word] + str_after

            print('\n\n')
            return Combined_case,DataFrame(position,index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TTS'],columns=['Start','End']),Combined_case,LFc,LBc,overlap,overlap_time,Combined_case_time

        #print('now : ',now_path+LAMP_result_path)
        
        
        Collect_target = []
        Collect_target_dGs = []
        for root, dirs, files in walk(now_path+LAMP_result_path):
            for file in files :
                if file.find('Final_Group') != -1 :
                    Final_Group = file
                    #print(Final_Group)
                    Collect_target_dG = []
                    with open(now_path+LAMP_result_path+Final_Group,'r') as file :
                        All_Targets = file.read()
                        #print(All_Targets)

                        Wanted = All_Targets.split('\n')
        
                        for each in range(len(Wanted)):
                            if each%6 ==0 :
                                if Wanted[each] != '':
                                    Collect_target.append(Wanted[each].replace(':','').replace(' ',''))
                                    search_line = Wanted[each].replace(' ','')
                                    search_line_Group = search_line[search_line.find('Group'):]
                                    Collect_target_dG.append(search_line_Group)
                                    
                    target_dir_path = Final_Group.replace('Final_Group_','').replace('.txt','') + '_PrimerList'
                    target_dG_file = Final_Group.replace('Final_Group_','').replace('.txt','') + '_Dimer_minimum_dG.txt'

                    with open(now_path+LAMP_result_path+target_dir_path+'/'+target_dG_file,'r') as target_dG_file_open :
                        Data_dG = target_dG_file_open.read()

                    for each_group in Collect_target_dG :
                        dG_from = Data_dG.find(each_group)+len(each_group)+18
                        dG_end = Data_dG[dG_from:].find('\n')+dG_from
                        Collect_target_dGs.append(Data_dG[dG_from:dG_end])
        #print(Collect_target_dGs)

        # Collect_target

        #print(len(Collect_target))
        #print(Collect_target)

        Start_End_Score = []
        for each_collect in Collect_target :
            mid = each_collect.find('_to_')
            mid2 = each_collect.find('_score_')+len('_score_')
            
            
            Start = int(each_collect[each_collect[:mid].rfind('_')+1:mid])
            End = int(each_collect[mid+4:mid+4+each_collect[mid+4:].find('_')])
            Score = int(each_collect[mid2:mid2+each_collect[mid2:].find('_')])
            '''
            Start = int(each_collect[each_collect.find(String_start)+len(String_start) : each_collect.find('_to_')])
            End = int(each_collect[each_collect.find('_to_')+len('_to_') : each_collect.find('_score_')])
            Score = int(each_collect[each_collect.find('_score_')+len('_score_') : each_collect.find('_ : G')])
            '''
            Start_End_Score.append([Start,End,Score])

        TFO_seq = read_csv(TTS_result_path)
        Raw_TFO_Start_End_Score = []
        for order in range(len(TFO_seq)):
            Raw_TFO_Start_End_Score.append([int(TFO_seq.loc[order]['Start']),int(TFO_seq.loc[order]['End']),int(TFO_seq.loc[order]['Score'])])

        TFO_sequence = []
        No = []
        for finding in range(len(Start_End_Score)) : 
            TFO_order = Raw_TFO_Start_End_Score.index(Start_End_Score[finding])
            No.append(TFO_order+1)
        #     print('No.'+str(TFO_order+1),end='\t')
            TFO_sequence.append(TFO_seq.loc[TFO_order]['TTS'])
        #     print(TFO_seq.loc[TFO_order]['TTS'])

        def Run():
            These_case = []
            These_case_overlap = []
            These_case_overlap_A = []
            These_case_overlap_Bubble = []
            These_case_overlap_C = []
            These_case_overlap_D = []
            These_case_overlap_tfo = []
            These_case_overlap_tfo_times = []
            These_case_statues = []
            These_case_TFO_length = []

            These_case_F3_len = []
            These_case_B3_len = []
            These_case_F2_len = []
            These_case_F1c_len = []
            These_case_B2_len = []
            These_case_B1c_len = []
            These_case_LF_len = []
            These_case_LB_len = []

            These_case_TFO_GCrate = []
            These_case_F3_GCrate = []
            These_case_B3_GCrate = []
            These_case_F2_GCrate = []
            These_case_F1c_GCrate = []
            These_case_B2_GCrate = []
            These_case_B1c_GCrate = []
            These_case_LF_GCrate = []
            These_case_LB_GCrate = []    

            These_case_F3_Tm = []
            These_case_B3_Tm = []
            These_case_F2_Tm = []
            These_case_F1c_Tm = []
            These_case_B2_Tm = []
            These_case_B1c_Tm = []
            These_case_LF_Tm = []
            These_case_LB_Tm = []      

            These_case_F3_5_dG = []
            These_case_B3_5_dG = []
            These_case_F2_5_dG = []
            These_case_F1c_5_dG = []
            These_case_B2_5_dG = []
            These_case_B1c_5_dG = []
            These_case_LF_5_dG = []
            These_case_LB_5_dG = [] 

            These_case_F3_3_dG = []
            These_case_B3_3_dG = []
            These_case_F2_3_dG = []
            These_case_F1c_3_dG = []
            These_case_B2_3_dG = []
            These_case_B1c_3_dG = []
            These_case_LF_3_dG = []
            These_case_LB_3_dG = []   

            These_case_TFO_Sequence = []
            These_case_F3_Sequence = []
            These_case_B3_Sequence = []
            These_case_F2_Sequence = []
            These_case_F1c_Sequence = []
            These_case_B2_Sequence = []
            These_case_B1c_Sequence = []
            These_case_FIP_Sequence = []
            These_case_BIP_Sequence = [] 
            These_case_LF_Sequence = []
            These_case_LB_Sequence = []  
            
            These_case_inner_min_dG = []

            Target_dir_lists = []
            for root, dirs, files in walk(now_path+LAMP_result_path):
                for dirr in dirs :
                    Target_dir_lists.append(dirr)

            print('\033[7;30;43m\t\t\t\tNo'+str(No[num])+'--'+Collect_target[num].replace('tfo','tts')+'\t\t\t\t\033[0m')
            print('\n')
            Oli='';F3='';B3='';F2='';F1c='';B2='';B1c='';LF='';LB='';TFO='';

            #Path = LAMP_result_path+Collect_target[num][:Collect_target[num].find(' :')]+'_PrimerList/'
            #Group = Collect_target[num][Collect_target[num].find(' :')+3:]
            Group = Collect_target[num][Collect_target[num].rfind('_') : ]+'_'
            Noo_start = Collect_target[num].find('no_')
            Noo_end = Collect_target[num].find('___')+1
            Noo = Collect_target[num][Noo_start:Noo_end]
            #print('\n\n')
            #print(Collect_target[num])
            
            #print('--Group : ',Group)
            for dirr in Target_dir_lists :
                if dirr.find(Noo)!= -1 :
                    Path = dirr
                    break
            #print('--Now : ',now_path+LAMP_result_path+Path)
            for root, dirs, files in walk(now_path+LAMP_result_path+Path):
                for file in files :
                    #print(file)
                    if file.find(Noo)!= -1 and file.find(Group)!= -1 and file.find('csv')!= -1 :
                        File = file
                        #print('--csv data : '+File)
                    elif file.find(Noo)!= -1 and file.find(Group.replace('_Group','_')[:-1]+'.')!= -1  and file.find('xls')== -1 and file.find('txt') == -1 and file.find('fa') != -1:
                        File2 = file
                        # file.find(Group.replace('_Group','_')[:-1]+'.')!= -1 and
                        #print('--'+Collect_target[num])
                        #print('--fasta data : '+File2)
                            

            LFs_LBs = read_csv(now_path+LAMP_result_path+Path+'/'+File)

            LFs = []
            LF_lens = []
            LF_Tms = []
            LF_5_dGs = []
            LF_3_dGs = []
            LF_GCrates = []

            LBs = []
            LB_lens = []
            LB_Tms = []
            LB_5_dGs = []
            LB_3_dGs = []
            LB_GCrates = []

            for each_ in range(len(LFs_LBs)):
                if (each_+1)%3 != 0 :
                    if LFs_LBs.loc[each_]['label'] == 'LF' : 
                        LFs.append(LFs_LBs.loc[each_]['Sequence'])
                        LF_lens.append(LFs_LBs.loc[each_]['len'])
                        LF_Tms.append(LFs_LBs.loc[each_]['Tm'])
                        LF_5_dGs.append(LFs_LBs.loc[each_]["5'dG"])
                        LF_3_dGs.append(LFs_LBs.loc[each_]["3'dG"])
                        LF_GCrates.append(LFs_LBs.loc[each_]['GCrate'])
                    else:
                        LBs.append(LFs_LBs.loc[each_]['Sequence'])
                        LB_lens.append(LFs_LBs.loc[each_]['len'])
                        LB_Tms.append(LFs_LBs.loc[each_]['Tm'])
                        LB_5_dGs.append(LFs_LBs.loc[each_]["5'dG"])
                        LB_3_dGs.append(LFs_LBs.loc[each_]["3'dG"])
                        LB_GCrates.append(LFs_LBs.loc[each_]['GCrate'])

            with open (now_path+LAMP_result_path+Path+'/'+File2,'r') as file2 :
                Oli = file2.read()

            Olis = Oli.split('\n')
            Oli = Olis[2][6:]
            #print('--'+Oli)

            TOP_path = now_path+LAMP_result_path+Path+'/'

            target_group_inner_primer = Group.replace('_Group','Primer_')
            for root, dirs, files in walk(TOP_path):
                for file in files :
            #         print(file)
                    if file.find(target_group_inner_primer)!= -1 and file.find('Group')== -1 and file.find('xlsx')!= -1 : # and file.find(Collect_target[num][:Collect_target[num].find(' :')])!= -1
                        TOP_File = file
                        #print('--Get Loop primer file : '+TOP_File)

            Inner_primer = TOP_path+TOP_File #Path+TOP_File.replace('~$','')

            primers = read_excel(Inner_primer,engine='openpyxl') #
            F3 = primers.loc[1]['Sequence'] 
            F3_len = primers.loc[1]['len']
            F3_Tm = primers.loc[1]['Tm']
            F3_5_dG = primers.loc[1]["5'dG"]
            F3_3_dG = primers.loc[1]["3'dG"]
            F3_GCrate = primers.loc[1]["GCrate"]

            B3_input = primers.loc[2]['Sequence']
            B3_len = primers.loc[2]['len']
            B3_Tm = primers.loc[2]['Tm']
            B3_5_dG = primers.loc[2]["5'dG"]
            B3_3_dG = primers.loc[2]["3'dG"]
            B3_GCrate = primers.loc[2]["GCrate"]
            B3c = reversed_complemented(B3_input)

            F2 = primers.loc[3]['Sequence']
            F2_len = primers.loc[3]['len']
            F2_Tm = primers.loc[3]['Tm']
            F2_5_dG = primers.loc[3]["5'dG"]
            F2_3_dG = primers.loc[3]["3'dG"]
            F2_GCrate = primers.loc[3]["GCrate"]        

            F1c_input = primers.loc[4]['Sequence']
            F1c_len = primers.loc[4]['len']
            F1c_Tm = primers.loc[4]['Tm']
            F1c_5_dG = primers.loc[4]["5'dG"]
            F1c_3_dG = primers.loc[4]["3'dG"]
            F1c_GCrate = primers.loc[4]["GCrate"]   
            F1 = reversed_complemented(F1c_input)

            B2_input = primers.loc[5]['Sequence']
            B2_len = primers.loc[5]['len']
            B2_Tm = primers.loc[5]['Tm']
            B2_5_dG = primers.loc[5]["5'dG"]
            B2_3_dG = primers.loc[5]["3'dG"]
            B2_GCrate = primers.loc[5]["GCrate"]  
            B2c = reversed_complemented(B2_input)


            B1c = primers.loc[6]['Sequence']
            B1c_len = primers.loc[6]['len']
            B1c_Tm = primers.loc[6]['Tm']
            B1c_5_dG = primers.loc[6]["5'dG"]
            B1c_3_dG = primers.loc[6]["3'dG"]
            B1c_GCrate = primers.loc[6]["GCrate"]         
            
            FIP = primers.loc[7]['Sequence']
            BIP = primers.loc[8]['Sequence']


            TFO = TFO_sequence[num]
            TFO_len = len(TFO)
            TFO_Tm = ''
            TFO_5_dG = ''
            TFO_3_dG = ''
            TFO_GCrate = '0.'+ str(int((TFO.count('G')+TFO.count('C')/len(TFO))*100))

            This_case = []
            This_case_overlap = []
            This_case_statues = []
            This_case_TFO_length = []

            try:
                for running_LFLB in range(int(Top)): # top

                    LF = LFs[running_LFLB]
                    LF_len = LF_lens[running_LFLB]
                    LF_Tm = LF_Tms[running_LFLB]
                    LF_5_dG = LF_5_dGs[running_LFLB]
                    LF_3_dG = LF_3_dGs[running_LFLB]
                    LF_GCrate = LF_GCrates[running_LFLB]

                    LB = LBs[running_LFLB]
                    LB_len = LB_lens[running_LFLB]
                    LB_Tm = LB_Tms[running_LFLB]
                    LB_5_dG = LB_5_dGs[running_LFLB]
                    LB_3_dG = LB_3_dGs[running_LFLB]
                    LB_GCrate = LB_GCrates[running_LFLB]

                    This_case_TFO_length.append(len(TFO))
                    These_case_TFO_length.append(len(TFO))
                    print('\033[7;30;43m\t\t\t\tNo'+str(No[num])+'_G'+Group.replace('Group','')+'_'+str(running_LFLB+1)+'\t\t\t\t\033[0m')

                    name_str = 'No'+str(No[num])+'_G'+Group.replace('Group','')+'_'+str(running_LFLB+1)
                    This_case.append(name_str)
                    These_case.append(name_str)

                    Mix , Position , Combined_case , LFc , LBc , TFO_overlap , TFO_overlap_times , Combined_case_time = run(Oli,F3,B3c,F2,F1,B2c,B1c,LF,LB,TFO)
                    LF_2_seq = LF
                    LB_2_seq = LB
                    LF_text = 'LF'
                    LB_text = 'LB'
                    if LFc :
                        LF_2_seq = reversed_complemented(LF)
                        LF_text = 'LFc'
                    if LBc :
                        LB_2_seq = reversed_complemented(LB)
                        LB_text = 'LBc'

                    TFO_LAMP = DataFrame( [ [F3,F3_len,F3_Tm,F3_5_dG,F3_3_dG,F3_GCrate,'F3',F3],[B3_input,B3_len,B3_Tm,B3_5_dG,B3_3_dG,B3_GCrate,'B3c',B3c],[F2,F2_len,F2_Tm,F2_5_dG,F2_3_dG,F2_GCrate,'F2',F2],[F1c_input,F1c_len,F1c_Tm,F1c_5_dG,F1c_3_dG,F1c_GCrate,'F1',F1],[B2_input,B2_len,B2_Tm,B2_5_dG,B2_3_dG,B2_GCrate,'B2c',B2c],[B1c,B1c_len,B1c_Tm,B1c_5_dG,B1c_3_dG,B1c_GCrate,'B1c',B1c],[LF,LF_len,LF_Tm,LF_5_dG,LF_3_dG,LF_GCrate,LF_text,LF_2_seq],[LB,LB_len,LB_Tm,LB_5_dG,LB_3_dG,LB_GCrate,LB_text,LB_2_seq],[TFO,TFO_len,TFO_Tm,TFO_5_dG,TFO_3_dG,TFO_GCrate,'TTS',TFO] ],columns=['LAMP experiment','len','Tm','5dG','3dG','GCrate','Label','Sequence'],index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TTS'])
                    These_case_F3_len.append(F3_len)
                    These_case_B3_len.append(B3_len)
                    These_case_F2_len.append(F2_len)
                    These_case_F1c_len.append(F1c_len)
                    These_case_B2_len.append(B2_len)
                    These_case_B1c_len.append(B1c_len)
                    These_case_LF_len.append(LF_len)
                    These_case_LB_len.append(LB_len)

                    These_case_TFO_GCrate.append(TFO_GCrate)
                    These_case_F3_GCrate.append(F3_GCrate)
                    These_case_B3_GCrate.append(B3_GCrate)
                    These_case_F2_GCrate.append(F2_GCrate)
                    These_case_F1c_GCrate.append(F1c_GCrate)
                    These_case_B2_GCrate.append(B2_GCrate)
                    These_case_B1c_GCrate.append(B1c_GCrate)
                    These_case_LF_GCrate.append(LF_GCrate)
                    These_case_LB_GCrate.append(LB_GCrate)   

                    These_case_F3_Tm.append(F3_Tm)
                    These_case_B3_Tm.append(B3_Tm)
                    These_case_F2_Tm.append(F2_Tm)
                    These_case_F1c_Tm.append(F1c_Tm)
                    These_case_B2_Tm.append(B2_Tm)
                    These_case_B1c_Tm.append(B1c_Tm)
                    These_case_LF_Tm.append(LF_Tm)
                    These_case_LB_Tm.append(LB_Tm)     

                    These_case_F3_5_dG.append(F3_5_dG)
                    These_case_B3_5_dG.append(B3_5_dG)
                    These_case_F2_5_dG.append(F2_5_dG)
                    These_case_F1c_5_dG.append(F1c_5_dG)
                    These_case_B2_5_dG.append(B2_5_dG)
                    These_case_B1c_5_dG.append(B1c_5_dG)
                    These_case_LF_5_dG.append(LF_5_dG)
                    These_case_LB_5_dG.append(LB_5_dG)

                    These_case_F3_3_dG.append(F3_3_dG)
                    These_case_B3_3_dG.append(B3_3_dG)
                    These_case_F2_3_dG.append(F2_3_dG)
                    These_case_F1c_3_dG.append(F1c_3_dG)
                    These_case_B2_3_dG.append(B2_3_dG)
                    These_case_B1c_3_dG.append(B1c_3_dG)
                    These_case_LF_3_dG.append(LF_3_dG)
                    These_case_LB_3_dG.append(LB_3_dG)   

                    These_case_TFO_Sequence.append(TFO)
                    These_case_F3_Sequence.append(F3)
                    These_case_B3_Sequence.append(B3_input)
                    These_case_F2_Sequence.append(F2)
                    These_case_F1c_Sequence.append(F1c_input)
                    These_case_B2_Sequence.append(B2_input)
                    These_case_B1c_Sequence.append(B1c)
                    These_case_FIP_Sequence.append(FIP)
                    These_case_BIP_Sequence.append(BIP)
                    These_case_LF_Sequence.append(LF)
                    These_case_LB_Sequence.append(LB) 

    #                 TFO_LAMP = DataFrame( [ [F3,'F3',F3],[B3_input,'B3c',B3c],[F2,'F2',F2],[F1c_input,'F1',F1],[B2_input,'B2c',B2c],[B1c,'B1c',B1c],[LF,LF_text,LF_2_seq],[LB,LB_text,LB_2_seq],[TFO,'TFO',TFO] ],columns=['LAMP experiment','Label','Sequence'],index=['F3','B3','F2','F1c','B2','B1c','LF','LB','TFO'])    
    #                 print(TFO_LAMP)
    #                 print(Position)
                    TFO_LAMP_all = TFO_LAMP.merge(Position, how='inner', left_index=True, right_index=True)
                    display(HTML(TFO_LAMP_all.to_html()))
                    print('\n\nThe TTS overlap part is:')
                    time_in_Combined_case = 0
                    all_Combined_case = 0
                    TFO_overlap_eachs = ''
                    for each_case in Combined_case :
                        TFO_overlap_each = TFO_overlap[all_Combined_case:all_Combined_case+int(Combined_case_time[time_in_Combined_case])]
                        print(each_case , Combined_case_time[time_in_Combined_case] , TFO_overlap_each)
                        all_Combined_case += int(Combined_case_time[time_in_Combined_case])
                        time_in_Combined_case += 1
                        if time_in_Combined_case != len(Combined_case) :
                            TFO_overlap_eachs += TFO_overlap_each + '-'
                        else:
                            TFO_overlap_eachs += TFO_overlap_each
                        
                    print('TTS overlap '+str(TFO_overlap_times)+' mer : '+TFO_overlap)
                    print('\n\n')

                    This_case_overlap.append(Combined_case)
                    These_case_overlap.append(Combined_case)
                    These_case_overlap_tfo.append(TFO_overlap_eachs)
                    These_case_overlap_tfo_times.append(TFO_overlap_times)

                    F3_position_start = Position.loc['F3']['Start']
                    F3_position_end = Position.loc['F3']['End']
                    B3c_position_start = Position.loc['B3']['Start']
                    B3c_position_end = Position.loc['B3']['End']
                    F2_position_start = Position.loc['F2']['Start']
                    F2_position_end = Position.loc['F2']['End']
                    F1_position_start = Position.loc['F1c']['Start']
                    F1_position_end = Position.loc['F1c']['End']
                    B2c_position_start = Position.loc['B2']['Start']
                    B2c_position_end = Position.loc['B2']['End']
                    B1c_position_start = Position.loc['B1c']['Start']
                    B1c_position_end = Position.loc['B1c']['End']
                    LF_position_start = Position.loc['LF']['Start']
                    LF_position_end = Position.loc['LF']['End']
                    LB_position_start = Position.loc['LB']['Start']
                    LB_position_end = Position.loc['LB']['End']
                    TFO_position_start = Position.loc['TTS']['Start']
                    TFO_position_end = Position.loc['TTS']['End']

                    CaseA = False
                    CaseBubble = False
                    CaseC = False
                    CaseD = False

                    # A
                    This_case_statues_ = []
                    This_case_overlap_ = 0
                    if Combined_case == [] and len(TFO) >= 10:
                        if F1_position_end<TFO_position_start and TFO_position_end<B1c_position_start:
                            print('Case A1','TTS length : ',len(TFO))
                            This_case_statues_.append('A1')

                            CaseA = True
                            
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('F1' in each_case or 'B1c' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            
                                
                        elif F2_position_end<TFO_position_start and TFO_position_end<B2c_position_start:
                            print('Case A2','TTS length : ',len(TFO))
                            This_case_statues_.append('A2')

                            CaseA = True
                            
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('F1' in each_case or 'B1c' in each_case or 'F2' in each_case or 'B2c' in each_case) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
    #                     elif F3_position_end<TFO_position_start and TFO_position_end<B3c_position_start:
    #                         print('Case A3','TFO length : ',len(TFO))
    #                         This_case_statues_.append('A3')

    #                         CaseA = True
                    if CaseA :
                        These_case_overlap_A.append(This_case_overlap_)
                    else:
                        These_case_overlap_A.append(-1)
                    This_case_overlap_ = 0
                    
                    # Bubble
                    time_in_Combined_case_Bubble = 0
                    Pass_Bubble = True
    #                 if Combined_case != [] :
    #                     for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['F1', 'TFO'],['TFO','F1'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c']  ] :
    #                         if each_combine_fail in Combined_case :
    #                             Pass_C = False
    #                             break

                    if Pass_Bubble : 
                        if TFO_position_start-F2_position_end < 0 and TFO_position_end-F2_position_end > 0 : # FIP
                            This_case_statues_.append('Bubble_FIP')
                            print('Case Bubble_FIP')
                            CaseBubble = True
                            
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('F1' in each_case or 'F2' in each_case  ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ += Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_Bubble < This_case_overlap_ :
                                time_in_Combined_case_Bubble = This_case_overlap_ 
                                This_case_overlap_ = 0
                                
                        if TFO_position_start-LB_position_end <0 and TFO_position_end-LB_position_end > 0 : # LB 
                            This_case_statues_.append('Bubble_LB')
                            print('Case Bubble_LB')
                            CaseBubble = True

                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('LB' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_Bubble < This_case_overlap_ :
                                time_in_Combined_case_Bubble = This_case_overlap_ 
                                This_case_overlap_ = 0
                                
                        if TFO_position_start-B2c_position_start <0 and TFO_position_end-B2c_position_start > 0 : # BIP
                            This_case_statues_.append('Bubble_BIP')
                            print('Case Bubble_BIP')
                            CaseBubble = True

                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('B2c' in each_case or 'B1c' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ += Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_Bubble < This_case_overlap_ :
                                time_in_Combined_case_Bubble = This_case_overlap_ 
                                This_case_overlap_ = 0
                                
                        if TFO_position_start-LF_position_start <0 and TFO_position_end-LF_position_start > 0 : # LF
                            This_case_statues_.append('Bubble_LF')
                            print('Case Bubble_LF')
                            CaseBubble = True

                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('LF' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_Bubble < This_case_overlap_ :
                                time_in_Combined_case_Bubble = This_case_overlap_ 
                                This_case_overlap_ = 0
                    if CaseBubble :
                        These_case_overlap_Bubble.append(time_in_Combined_case_Bubble)
                    else:
                        These_case_overlap_Bubble.append(-1)
                    This_case_overlap_ = 0
                    
                    # C
                    time_in_Combined_case_C = 0
                    Pass_C = True
    #                 if Combined_case != [] :
    #                     for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['F1', 'TFO'],['TFO','F1'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c']  ] :
    #                         if each_combine_fail in Combined_case :
    #                             Pass_C = False
    #                             break

                    if Pass_C : 
                        if TFO_position_start-LF_position_end <=1 and TFO_position_start-LF_position_start >= 0 : # LF behind
                            print('Case C_LF')
                            This_case_statues_.append('C_LF')

                            CaseC = True
                            
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('LF' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_C < This_case_overlap_ :
                                time_in_Combined_case_C = This_case_overlap_    
                        if TFO_position_end-LB_position_end <=0 and TFO_position_end-LB_position_start >= -1 : # LB infront
                            print('Case C_LB')
                            This_case_statues_.append('C_LB')

                            CaseC = True

                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('LB' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_C < This_case_overlap_ :
                                time_in_Combined_case_C = This_case_overlap_  
                                This_case_overlap_ = 0
                    if CaseC :
                        These_case_overlap_C.append(time_in_Combined_case_C)
                    else:
                        These_case_overlap_C.append(-1)
                    This_case_overlap_ = 0
                    # D
                    time_in_Combined_case_D = 0
                    if TFO_position_end-F2_position_end <=0 and TFO_position_end-F2_position_start >= -1 and TFO_position_start-F2_position_start <= 0 : # F2                  
                        Pass_D = True
    #                     if Combined_case != [] :
    #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F1', 'TFO'],['TFO','F1'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
    #                             if each_combine_fail in Combined_case :
    #                                 Pass_D = False
    #                                 break
                        if Pass_D:
                            print('Case D_F2')
                            This_case_statues_.append('D_F2')

                            CaseD = True
                        
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('F2' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_D < This_case_overlap_ :
                                time_in_Combined_case_D = This_case_overlap_  
                                This_case_overlap_ = 0
                    if TFO_position_end-F1_position_end <=0 and TFO_position_end-F1_position_start >= -1 and TFO_position_start-F1_position_start <= 0 : # F1                 
                        Pass_D = True
    #                     if Combined_case != [] :
    #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['B2c', 'TFO'],['TFO','B2c'],['B1c', 'TFO'],['TFO','B1c'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
    #                             if each_combine_fail in Combined_case :
    #                                 Pass_D = False
    #                                 break
                        if Pass_D:
                            print('Case D_F1')
                            This_case_statues_.append('D_F1')

                            CaseD = True

                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('F1' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_D < This_case_overlap_ :
                                time_in_Combined_case_D = This_case_overlap_  
                                This_case_overlap_ = 0
                    if TFO_position_start-B2c_position_end <=1 and TFO_position_start-B2c_position_start >= 0 and TFO_position_end-B2c_position_end >= 0 : # B2c                 
                        Pass_D = True
    #                     if Combined_case != [] :
    #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F1', 'TFO'],['TFO','F1'],['F2', 'TFO'],['TFO','F2'],['B1c', 'TFO'],['TFO','B1c'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
    #                             if each_combine_fail in Combined_case :
    #                                 Pass_D = False
    #                                 break
                        if Pass_D:
                            print('Case D_B2c')
                            This_case_statues_.append('D_B2c')

                            CaseD = True
                        
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('B2c' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_D < This_case_overlap_ :
                                time_in_Combined_case_D = This_case_overlap_ 
                                This_case_overlap_ = 0                                
                    if TFO_position_start-B1c_position_end <=1 and TFO_position_start-B1c_position_start >= 0 and TFO_position_end-B1c_position_end >= 0 : # B1c                 
                        Pass_D = True
    #                     if Combined_case != [] :
    #                         for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3c', 'TFO'],['TFO','B3c'],['F2', 'TFO'],['TFO','F2'],['B2c', 'TFO'],['TFO','B2c'],['F1', 'TFO'],['TFO','F1'],['LF','TFO'],['TFO','LF'],['LB','TFO'],['TFO','LB']  ] :
    #                             if each_combine_fail in Combined_case :
    #                                 Pass_D = False
    #                                 break
                        if Pass_D:
                            print('Case D_B1c')
                            This_case_statues_.append('D_B1c')

                            CaseD = True
        
                            time_in_Combined_case = 0
                            for each_case in Combined_case :
                                if 'TTS' in each_case and ('B1c' in each_case ) :
                                    #print(each_case , Combined_case_time[time_in_Combined_case])
                                    This_case_overlap_ = Combined_case_time[time_in_Combined_case]
                                time_in_Combined_case += 1
                            if time_in_Combined_case_D < This_case_overlap_ :
                                time_in_Combined_case_D = This_case_overlap_  
                                This_case_overlap_ = 0

                    if CaseD :
                        These_case_overlap_D.append(time_in_Combined_case_D)
                    else:
                        These_case_overlap_D.append(-1)
                    This_case_overlap_ = 0
                    # Other
                    if CaseA == False and CaseBubble == False and CaseC == False and CaseD == False : 
                        print('Other Case')
                        This_case_statues_.append('Other')

                    This_case_statues.append(This_case_statues_) 
                    These_case_statues.append(This_case_statues_) 
                    These_case_inner_min_dG.append(Collect_target_dGs[num])

    #                 Pass_C = True
    #                 Check_if_else_C = False
    #                 for each_combine_fail in [ ['F3', 'TFO'],['TFO','F3'],['B3', 'TFO'],['TFO','B3'],['F2', 'TFO'],['TFO','F2'],['F1c', 'TFO'],['TFO','F1c'],['B2', 'TFO'],['TFO','B2'],['B1c', 'TFO'],['TFO','B1c']  ] :
    #                     if Combined_case!= []:
    #                         if each_combine_fail in Combined_case :
    #                             Pass_C = False
    #                             break
    # #                 print(Pass_C)
    #                 if Pass_C :
    #                     if abs(TFO_position-LF_position_end) <= 10 or abs(TFO_position_end-LF_position_start) <= 10 or abs(TFO_position-LB_position_end) <= 10 or abs(TFO_position_end-LB_position_start) <= 10 :
    #                         print('Case C')
    #                         This_case_statues.append('C')
    #                         These_case_statues.append('C')
    #                         Check_if_else_C = True

    #                 if  Check_if_else_C == False:     
    #                     if TFO_position <= F2_position :
    #                         print('Case D')
    #                         This_case_statues.append('D')
    #                         These_case_statues.append('D')

    #                     elif (F3_position <= TFO_position and  TFO_position<= B3_position ) or (B3_position <= TFO_position and  TFO_position<= F3_position ) :
    #                         This_case_statues.append('A')
    #                         These_case_statues.append('A')

    #                     else :
    #                         print('Case Other')
    #                         This_case_statues.append('Other')
    #                         These_case_statues.append('Other')

                    print('----------------------------------\n')

            except:
                running_LFLB -= 1


            print('Summary : ',running_LFLB+1,' LF&LB\n')
            D = DataFrame([This_case_statues,This_case_overlap,This_case_TFO_length],columns=This_case,index=['Model type','Overlapping part','TTS length']).T
            display(HTML(D.to_html()))
            #print(D)
            #print('\n\n\n\n\n\n')

            #print('Summary')
            Columns_ = [each for each in range(1,len(These_case)+1)]


            Result_1 = DataFrame([These_case,These_case_statues,These_case_overlap,These_case_overlap_tfo,These_case_overlap_tfo_times,These_case_overlap_A,These_case_overlap_Bubble,These_case_overlap_C,These_case_overlap_D,These_case_TFO_length] ,index=['ID','Model_type','Overlapping_part','TTS_overlap','TTS_overlap_mers','TTS_overlap_mers_A_max','TTS_overlap_mers_Bubble_max','TTS_overlap_mers_C_max','TTS_overlap_mers_D_max','TTS_length'],columns=Columns_).T 
            Result_2 = DataFrame([These_case,These_case_statues,These_case_overlap,These_case_overlap_tfo,These_case_overlap_tfo_times,These_case_overlap_A,These_case_overlap_Bubble,These_case_overlap_C,These_case_overlap_D,These_case_TFO_length,These_case_F3_len,These_case_B3_len,These_case_F2_len,These_case_F1c_len,These_case_B2_len,These_case_B1c_len,These_case_LF_len,These_case_LB_len,These_case_TFO_GCrate,These_case_F3_GCrate,These_case_B3_GCrate,These_case_F2_GCrate,These_case_F1c_GCrate,These_case_B2_GCrate,These_case_B1c_GCrate,These_case_LF_GCrate,These_case_LB_GCrate,These_case_F3_Tm,These_case_B3_Tm,These_case_F2_Tm,These_case_F1c_Tm,These_case_B2_Tm,These_case_B1c_Tm,These_case_LF_Tm,These_case_LB_Tm,These_case_F3_5_dG,These_case_B3_5_dG,These_case_F2_5_dG,These_case_F1c_5_dG,These_case_B2_5_dG,These_case_B1c_5_dG,These_case_LF_5_dG,These_case_LB_5_dG,These_case_F3_3_dG,These_case_B3_3_dG,These_case_F2_3_dG,These_case_F1c_3_dG,These_case_B2_3_dG,These_case_B1c_3_dG,These_case_LF_3_dG,These_case_LB_3_dG,These_case_inner_min_dG,These_case_TFO_Sequence,These_case_F3_Sequence,These_case_B3_Sequence,These_case_F2_Sequence,These_case_F1c_Sequence,These_case_B2_Sequence,These_case_B1c_Sequence,These_case_FIP_Sequence,These_case_BIP_Sequence,These_case_LF_Sequence,These_case_LB_Sequence] ,index=['ID','Model_type','Overlapping_part','TTS_overlap','TTS_overlap_mers','TTS_overlap_mers_A_max','TTS_overlap_mers_Bubble_max','TTS_overlap_mers_C_max','TTS_overlap_mers_D_max','TTS_length','F3_len','B3_len','F2_len','F1c_len','B2_len','B1c_len','LF_len','LB_len','TTS_GCrate','F3_GCrate','B3_GCrate','F2_GCrate','F1c_GCrate','B2_GCrate','B1c_GCrate','LF_GCrate','LB_GCrate','F3_Tm','B3_Tm','F2_Tm','F1c_Tm','B2_Tm','B1c_Tm','LF_Tm','LB_Tm','F3_5dG','B3_5dG','F2_5dG','F1c_5dG','B2_5dG','B1c_5dG','LF_5dG','LB_5dG','F3_3dG','B3_3dG','F2_3dG','F1c_3dG','B2_3dG','B1c_3dG','LF_3dG','LB_3dG','dimer_minimum_dG','TTS_Sequence','F3_Sequence','B3_Sequence','F2_Sequence','F1c_Sequence','B2_Sequence','B1c_Sequence','FIP_Sequence','BIP_Sequence','LF_Sequence','LB_Sequence' ],columns=Columns_).T 
            return Result_1,Result_2

        Summary,Summary_detail = Run()
        
        exporter = HTMLExporter()
        output_notebook = nbformat.read(notebook_name, as_version=4)

        output, resources = exporter.from_notebook_node(output_notebook)
        #codecs.open(output_file_name+'.html', 'w', encoding='utf-8').write(output)
        
        Summary_detail.to_csv(Summary_detail_csv)
        Summary_detail = Summary_detail[list(Summary_detail.columns)[4:9]]
        #pfr = pandas_profiling.ProfileReport(Summary_detail)
        #pfr.to_file(Summary_detail_report)


class get_info() :
    
    def __init__(self,):

        return None
    def run(self,LAMP_result_path,TTS_result_path):
        from pandas import DataFrame,read_csv
        from os import listdir,walk
        from os.path import isfile, isdir, join
        import os
        All_Targets = ''
        for root, dirs, files in walk(LAMP_result_path):
            for filee in files :
                if filee.find('Final_Group') != -1 :
                    Final_Group_data = filee
                    
                    with open(LAMP_result_path+Final_Group_data,'r') as file :
                        All_Target = file.read()
                        
                        All_Targets += All_Target

        Wanted = All_Targets.split('\n')
        Collect_target = []

        for each in range(len(Wanted)):
            if each%6 ==0 :
                if Wanted[each] != '':
                    Collect_target.append(Wanted[each])

        # Collect_target

        len(Collect_target)

        String_start = 'no_'+LAMP_result_path[LAMP_result_path.rfind('no')+2:-1]+'_'
        String_start

        Start_End_Score = []
        for each_collect in Collect_target :
            mid = each_collect.find('_to_')
            mid2 = each_collect.find('_score_')+len('_score_')

            Start = int(each_collect[each_collect[:mid].rfind('_')+1:mid])
            End = int(each_collect[mid+4:mid+4+each_collect[mid+4:].find('_')])
            Score = int(each_collect[mid2:mid2+each_collect[mid2:].find('_')])

            Start_End_Score.append([Start,End,Score])

        TFO_seq = read_csv(TTS_result_path)
        Raw_TFO_Start_End_Score = []
        for order in range(len(TFO_seq)):
            Raw_TFO_Start_End_Score.append([int(TFO_seq.loc[order]['Start']),int(TFO_seq.loc[order]['End']),int(TFO_seq.loc[order]['Score'])])

        TFO_sequence = []
        No = []
        for finding in range(len(Start_End_Score)) : 
            TFO_order = Raw_TFO_Start_End_Score.index(Start_End_Score[finding])
            No.append(TFO_order+1)
        #     print('No.'+str(TFO_order+1),end='\t')
            TFO_sequence.append(TFO_seq.loc[TFO_order]['TTS'])
        #     print(TFO_seq.loc[TFO_order]['TTS'])

        return Collect_target,No        
        

    def stop_show(self,data):
    
        from nbconvert import HTMLExporter
        import nbformat
        import codecs
        from pandas import DataFrame,read_csv
        
        

        with open('record.txt','r',encoding='utf-8') as file_record :
            Text = file_record.read()
            
        Top = int(Text.split('\n')[0] )
        TTS_result_path = Text.split('\n')[1]
        LAMP_result_path = Text.split('\n')[2]
        notebook_name = Text.split('\n')[3]
        output_file_path = Text.split('\n')[4]
        output_data_name = Text.split('\n')[5]
        num = int(Text.split('\n')[6])
        
        Collect_target,No = self.run(LAMP_result_path,TTS_result_path)
        
        exporter = HTMLExporter()
        output_notebook = nbformat.read(notebook_name, as_version=4)
        output, resources = exporter.from_notebook_node(output_notebook)
        codecs.open(data, 'w', encoding='utf-8').write(output)