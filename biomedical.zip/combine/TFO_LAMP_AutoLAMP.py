from selenium.webdriver import Chrome
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
from time import sleep
from os import listdir,path,rename,walk,makedirs,remove
from pandas import concat,DataFrame
from datetime import datetime
from random import randint
from getpass import getuser
import sys
import os
import warnings
warnings.filterwarnings("ignore")
#import chromedriver_binary

now_path = '/usr/src/app/' #os.getcwd() + '/'
os.chdir(now_path)
print('dir path : '+ now_path)

user_name = getuser() # Get computer path name
Default_setting = '2'#input('This use is preset, please fill in "1", and if adjustment is required, please fill in "2"');print('')
if Default_setting.replace('"','') == "1" :
    Default = True # True : Default top 5 
else :
    Default = False # False : Cancel the preset & Could adjust the details
    
### Detail Settings ###
if Default == False :
    print('--Start')
    Limit_setting = 'Y'#input('    Do you want to adjust the "upper limit" of Inner primer? ')
    if Limit_setting.upper() == 'Y' :
        upper_Limit = sys.argv[1] #input('        

    Tm_range_setting = 'N'#input('    Do you want to adjust the "Tm range" of Inner primer? ')
#     if Tm_range_setting.upper() == 'Y' :
#         Tm_F1c_B1c_range = input('        
#         Tm_F2_B2_range = input('        
#         Tm_F3_B3_range = input('        
#         Tm_F1c_B1c_from = Tm_F1c_B1c_range.split('~')[0]
#         Tm_F1c_B1c_to = Tm_F1c_B1c_range.split('~')[1]
#         Tm_F2_B2_from = Tm_F2_B2_range.split('~')[0]
#         Tm_F2_B2_to = Tm_F2_B2_range.split('~')[1]
#         Tm_F3_B3_from = Tm_F3_B3_range.split('~')[0]
#         Tm_F3_B3_to = Tm_F3_B3_range.split('~')[1]
        
    Distances_range_setting = 'N'#input('    Do you want to adjust the "Distances range" of Inner primer? ')
#     if Distances_range_setting.upper() == 'Y' :
#         Distance_F1c_B1c_range = input('        
#         Distance_F2_B2_range = input('        
#         Distance_F1c_F2_range = input('        
#         Distance_F2_F3_range = input('        
#         Distances_F1c_B1c_from = Distance_F1c_B1c_range.split('~')[0]
#         Distances_F1c_B1c_to = Distance_F1c_B1c_range.split('~')[1]
#         Distances_F2_B2_from = Distance_F2_B2_range.split('~')[0]
#         Distances_F2_B2_to = Distance_F2_B2_range.split('~')[1]
#         Distances_F1c_F2_from = Distance_F1c_F2_range.split('~')[0]
#         Distances_F1c_F2_to = Distance_F1c_F2_range.split('~')[1]  
#         Distances_F2_F3_from = Distance_F2_F3_range.split('~')[0]
#         Distances_F2_F3_to = Distance_F2_F3_range.split('~')[1]   
### Detail Settings ###

choose = sys.argv[2] #'you have selected ' + str(input('Your Mode : ')).upper()
TOP_path = now_path+sys.argv[3] #input('Input path : ') # Example : 'C:/Users/Tingchun.TC.Hung/Desktop/AutoLAMP/Running/Update_3/'
save_path = sys.argv[4] #input('Output path : ') # Example : 'C:/Users/Tingchun.TC.Hung/Desktop/AutoLAMP/Running/Update_3_result/'

if not os.path.isdir(now_path+save_path):
    os.mkdir(now_path+save_path)

### Find the latest file in the directory ###
def find_new_file(dir_) :
    file_lists = listdir(dir_)
    file_lists.sort(key=lambda fn: path.getmtime(dir_ + "\\" + fn)
    if not path.isdir(dir_ + "\\" + fn) else 0)
    file = path.join(dir_, file_lists[-1])
    return file
### Find the latest file in the directory ###

### chrome_options set up ###
def enable_download_headless(browser,download_dir) :
    browser.command_executor._commands["send_command"] = ("POST", '/session/$sessionId/chromium/send_command')
    params = {'cmd':'Page.setDownloadBehavior', 'params': {'behavior': 'allow', 'downloadPath': download_dir}}
    command_result = browser.execute("send_command", params)
chrome_options = Options()
download_location = "C:\\Users\\"+user_name+"\\Downloads\\"
prefs = {'download.default_directory': download_location,'download.prompt_for_download': False,'download.directory_upgrade': True,'safebrowsing.enabled': False,'safebrowsing.disable_download_protection': True}
chrome_options.add_experimental_option('prefs', prefs)
chrome_options.add_argument('--headless') # No interface operation
#driver = webdriver.Remote("http://localhost:4000", options=chrome_options);enable_download_headless(driver, download_location)
#driver2 = webdriver.Remote("http://localhost:4000", options=chrome_options);enable_download_headless(driver2, download_location)

driver = Chrome(chrome_options=chrome_options);enable_download_headless(driver, download_location)
driver2 = Chrome(chrome_options=chrome_options);enable_download_headless(driver2, download_location)
print('--Chrome ready')
### chrome_options set up ###

def Progress(continue_position):
    print('target fasta path : '+TOP_path)
    global running ; running = True
    if( TOP_path != '' ):

        ### Get fasta files in the folder ###
        count = 0
        for root, dirs, files in walk(TOP_path):
            for each_paper in files :
                if(each_paper[each_paper.rfind('.'):]=='.fasta' or each_paper[each_paper.rfind('.'):]=='.fa' or each_paper[each_paper.rfind('.'):]=='.fas' ):
                    count+=1         
        ### Get fasta files in the folder ###
        if(count!=0):
            Count_success_primer = []
            n = 0 ; n2 = 0
            driver.get("http://primerexplorer.jp/lampv5e/index.html")  # Open the LAMP website
            print('--Open the LAMP website')
            print('--upload_data : '+upload_data) # /html/body/form/div[2]/div/div/div/div[2]/div/input           
            driver.find_element_by_xpath("/html/body/form/div[2]/div/div/div/div[2]/div/input").send_keys(upload_data) # Upload file
            driver.find_element_by_xpath("//button/span").click() # 
            print('--upload_data ready...')
            if Default :
                driver.find_element_by_xpath("(//button[@type='button'])[11]").click() # Generate
            else:
                driver.find_element_by_xpath("//form[@id='main']/div/div/div[9]/div[2]/button").click()
                ### Setting ###
                if Tm_range_setting.upper() == 'Y' :
                    driver.find_element_by_name("tm_f1cb1c_from").click()
                    driver.find_element_by_name("tm_f1cb1c_from").clear()
                    driver.find_element_by_name("tm_f1cb1c_from").send_keys(Tm_F1c_B1c_from)
                    driver.find_element_by_name("tm_f1cb1c_to").click()
                    driver.find_element_by_name("tm_f1cb1c_to").clear()
                    driver.find_element_by_name("tm_f1cb1c_to").send_keys(Tm_F1c_B1c_to)

                    driver.find_element_by_name("tm_f2b2_from").click()
                    driver.find_element_by_name("tm_f2b2_from").clear()
                    driver.find_element_by_name("tm_f2b2_from").send_keys(Tm_F2_B2_from)
                    driver.find_element_by_name("tm_f2b2_to").click()
                    driver.find_element_by_name("tm_f2b2_to").clear()
                    driver.find_element_by_name("tm_f2b2_to").send_keys(Tm_F2_B2_to)

                    driver.find_element_by_name("tm_f3b3_from").click()
                    driver.find_element_by_name("tm_f3b3_from").clear()
                    driver.find_element_by_name("tm_f3b3_from").send_keys(Tm_F3_B3_from)
                    driver.find_element_by_name("tm_f3b3_to").click()
                    driver.find_element_by_name("tm_f3b3_to").clear()
                    driver.find_element_by_name("tm_f3b3_to").send_keys(Tm_F3_B3_to)
                if Distances_range_setting.upper() == 'Y' :
                    driver.find_element_by_name("distance_f2b2_from").click()
                    driver.find_element_by_name("distance_f2b2_from").clear()
                    driver.find_element_by_name("distance_f2b2_from").send_keys(Distances_F2_B2_from)
                    driver.find_element_by_name("distance_f2b2_to").click()
                    driver.find_element_by_name("distance_f2b2_to").clear()
                    driver.find_element_by_name("distance_f2b2_to").send_keys(Distances_F2_B2_to)

                    driver.find_element_by_name("distance_f1cf2_from").click()
                    driver.find_element_by_name("distance_f1cf2_from").clear()
                    driver.find_element_by_name("distance_f1cf2_from").send_keys(Distances_F1c_F2_from)
                    driver.find_element_by_name("distance_f1cf2_to").click()
                    driver.find_element_by_name("distance_f1cf2_to").clear()
                    driver.find_element_by_name("distance_f1cf2_to").send_keys(Distances_F1c_F2_to)

                    driver.find_element_by_name("distance_f2f3_from").click()
                    driver.find_element_by_name("distance_f2f3_from").clear()
                    driver.find_element_by_name("distance_f2f3_from").send_keys(Distances_F2_F3_from)
                    driver.find_element_by_name("distance_f2f3_to").click()
                    driver.find_element_by_name("distance_f2f3_to").clear()
                    driver.find_element_by_name("distance_f2f3_to").send_keys(Distances_F2_F3_to)

                    driver.find_element_by_name("distance_f1cb1c_from").click()
                    driver.find_element_by_name("distance_f1cb1c_from").clear()
                    driver.find_element_by_name("distance_f1cb1c_from").send_keys(Distances_F1c_B1c_from)
                    driver.find_element_by_name("distance_f1cb1c_to").click()
                    driver.find_element_by_name("distance_f1cb1c_to").clear()
                    driver.find_element_by_name("distance_f1cb1c_to").send_keys(Distances_F1c_B1c_to)
                if Limit_setting.upper() == 'Y' :
                    driver.find_element_by_name("target_limit_sets").click()
                    driver.find_element_by_name("target_limit_sets").clear()
                    driver.find_element_by_name("target_limit_sets").send_keys(upper_Limit)
                ### Setting ###
                driver.find_element_by_xpath("(//button[@type='button'])[11]").click() # Generate
                
            success_click = True ; sleeping_sec = 0 
            while success_click :
                progress = driver.find_element_by_xpath('//*[@id="msgtxt"]').text
                if progress == 'in progress...' :
                    sleep(1);sleeping_sec += 1
                else:
                    success_click = False
                    inner_primer_sets = driver.find_element_by_xpath('//*[@id="msgtxt"]').text
                    inner_primer_sets_start_position = inner_primer_sets.find('\n') +2
                    inner_primer_sets_end_position = inner_primer_sets[inner_primer_sets_start_position:].find(' Primer set(s)') + inner_primer_sets_start_position
                    with open(now_path+save_path+this_data_name+'_first stage.txt','a') as Inner_primer_file:
                        Inner_primer_file.write('Primer set(s) : '+inner_primer_sets[inner_primer_sets_start_position:inner_primer_sets_end_position]+'\n')
                        Inner_primer_file.write('Detail : '+inner_primer_sets)
                    
            if Default :
                driver.find_element_by_id("btnDisplay").click() # Display
                Page = 2;success_click = True
            else:
                start_page = 0
                if continue_position != 1 :
                    start_page = int(continue_position/100)
                    if continue_position%100 == 0 :
                        start_page -= 1
                for page in range(start_page,10):
                    try:
                        driver.find_element_by_id("disp_pages").click()
                        Select(driver.find_element_by_id("disp_pages")).select_by_visible_text(str(page+1))
                        driver.find_element_by_id("disp_pages").click()
                        driver.find_element_by_id("btnDisplay").click() # Display
                        sleep(2)
                        if page == 9 :
                            Page = 11
                    except:
                        Page = page+1  
                        break                                     
            sleep(2)
            handles = driver.window_handles 

            def run_primer(id_,Group,Group_name,save_path):
                print('--Run primer')
                index = ['primer1','primer2','primer3','primer4','primer5','primer6','4<->3','6<->5']
                columns = ['label',"5'pos","3'pos",'len','Tm',"5'dG","3'dG",'GCrate','Sequence']
                for run_primers in [3,4,7,8,9,10]:
                    save_list = []
                    for each_index in range(2,11):
                        primer = driver.find_element_by_xpath('//*[@id="'+str(id_)+'"]/tbody/tr['+str(run_primers)+']/td['+str(each_index)+']').text
                        save_list.append(str(primer))
                    primer = driver.find_element_by_xpath('//*[@id="'+str(id_)+'"]/tbody/tr['+str(run_primers)+']/td['+str(each_index)+']').text
                    Group.append(save_list)
                for run_primer_combine in range(5,7):
                    primer_combine = driver.find_element_by_xpath('//*[@id="'+str(id_)+'"]/tbody/tr['+str(run_primer_combine)+']/td[2]').text
                    primer_combine2 = driver.find_element_by_xpath('//*[@id="'+str(id_)+'"]/tbody/tr['+str(run_primer_combine)+']/td[5]').text
                    primer_combine3 = driver.find_element_by_xpath('//*[@id="'+str(id_)+'"]/tbody/tr['+str(run_primer_combine)+']/td[10]/span').text
                    Group.append([primer_combine,'','',primer_combine2,'','','','',primer_combine3])
                group_pd = DataFrame(Group,index=index,columns=columns)
                save_group = DataFrame(columns,columns=[Group_name],index=columns).T
                save_group_end = DataFrame(['------------------' for i in range(len(columns))],columns=[Group_name],index=columns).T

                return_data = concat([save_group,group_pd,save_group_end])                 
                dimer_minimum_dG = driver.find_element_by_xpath('//*[@id="'+str(id_)+'"]/tbody/tr[1]/td[5]').text
                with open(save_path,'w') as file :
                    file.write('designID=210813095754'+'\n')
                    file.write('primerID='+id_+'\n') # 'Group'+str(1+(int((continue_position-move_100_case)/100)+switch_to_window-1)*100+running_other)
                    file.write('query='+Target_Sequence_for_All+'\n')
                    str_seq_len = ''
                    for add_ in range(len(Target_Sequence_for_All)) :
                        str_seq_len += '*'
                    file.write('consensus='+str_seq_len+'\n')
                    file.write('oligo=0.1'+'\n')
                    file.write('sodium=50.0'+'\n')
                    file.write('magnesium=4.0'+'\n')
                    file.write('dg_threshold_5=-3'+'\n')
                    file.write('dg_threshold_3=-4'+'\n')
                    file.write('F3_5pos='+return_data["5'pos"].values[1]+'\n')
                    file.write('F3_3pos='+return_data["3'pos"].values[1]+'\n')
                    file.write('F2_5pos='+return_data["5'pos"].values[3]+'\n')
                    file.write('F2_3pos='+return_data["3'pos"].values[3]+'\n')
                    file.write('F1c_5pos='+return_data["5'pos"].values[4]+'\n')
                    file.write('F1c_3pos='+return_data["3'pos"].values[4]+'\n')
                    file.write('B1c_5pos='+return_data["5'pos"].values[6]+'\n')
                    file.write('B1c_3pos='+return_data["3'pos"].values[6]+'\n')
                    file.write('B2_5pos='+return_data["5'pos"].values[5]+'\n')
                    file.write('B2_3pos='+return_data["3'pos"].values[5]+'\n')
                    file.write('B3_5pos='+return_data["5'pos"].values[2]+'\n')
                    file.write('B3_3pos='+return_data["3'pos"].values[2]+'\n')
                save_path2 = save_path[:save_path.rfind('/')]+''
                return  return_data , dimer_minimum_dG

            def copy_to_save_path(choose,save_excel_path,user_name,group_number,n2,upload_data2):
                columns = ['label',"5'pos","3'pos",'len','Tm',"5'dG","3'dG",'GCrate','Sequence']
                driver2.get("http://primerexplorer.jp/lampv5e/index.html")
                driver2.find_element_by_xpath("/html/body/form/div[2]/div/div/div/div[2]/div/input").send_keys(upload_data2)
                driver2.find_element_by_xpath("//button[@type='submit']").click()
                driver2.find_element_by_xpath("//button[@type='button']").click()

                success_click = True
                sleeping_sec = 0
                while success_click :
                    progress = driver2.find_element_by_xpath('//*[@id="msgtxt"]').text
                    if progress == 'in progress...' :
                        sleep(1)
                        sleeping_sec += 1
                    else:
                        success_click = False

                primer_id1 = driver2.find_element_by_xpath('//*[@id="msgtxt"]').text
                Primer_sets = '0'
                pieces = ''
                mode = ''
                Loop_primer_index = ''
                if(primer_id1.split("\n")[-1].split()[0]!='Could'):
                    if(primer_id1.split("\n")[2].split()[2][:-3]=='set'):
                        Primer_sets = primer_id1.split("\n")[2].split()[0]
                        mode = 'Best'
                    elif(primer_id1.split("\n")[2].split()[2][:-3]=='piece' or primer_id1.split("\n")[2].split()[2][:-3]=='set'):
                        pieces = primer_id1.split("\n")[2].split()[0]
                        mode = 'Sec'
                else:
                    Primer_sets = '0'
                LF = primer_id1.split()[4].split("=")[1].replace(",","")
                LB = primer_id1.split()[5].split("=")[1]
                Run_complete = False
                print('----Sec round loop primer search2')
                if(choose=='you have selected A' or choose=='Preset'):
                    Run_complete = False
                    Loop_primer_index = ''

                    if(primer_id1.split("\n")[-1].split()[0]!='Could'):
                        driver2.find_element_by_id("btnDisplay").click()
                        pass_num = True
                        sleep(2)
                        handles2 = driver2.window_handles 
                        driver2.switch_to.window(handles2[-1])  

                        pass_primer_num = driver2.find_element_by_xpath('/html/body/form[1]/font/p/b').text
                        primer_num = pass_primer_num.split()[1]
                        handles__1 = driver2.window_handles 

                        driver2.find_element_by_name("ids").click()
                        driver2.find_element_by_xpath("//button[@type='button']").click()

                        success_click = True
                        sleeping_sec = 0
                        while success_click :
                            handles__2 = driver2.window_handles 
                            if len(handles__1) == len(handles__2) and sleeping_sec <= 15:
                                sleep(1)
                                sleeping_sec += 1
                            else:
                                success_click = False                                                    

                        handles2 = driver2.window_handles 
                        driver2.switch_to.window(handles2[-1]) 
                        sleep(2)
                        Loop_primer_index = driver2.find_element_by_xpath('//*[@id="1"]/tbody/tr[3]/td[2]').text
                else:
                    if(choose=='you have selected B'):
                        if(int(LF)!=0 and int(LB)!=0 and Primer_sets != '0'):
                            Run_complete = True
                    else:
                        Run_complete = True

                    if(Run_complete):
                        try :
                            driver2.find_element_by_id("btnDisplay").click()
                            pass_num = True
                            sleep(2)
                            handles2 = driver2.window_handles 
                            driver2.switch_to.window(handles2[-1])  
                            pass_primer_num = driver2.find_element_by_xpath('/html/body/form[1]/font/p/b').text
                            primer_num = pass_primer_num.split()[1]
                            driver2.find_element_by_name("ids").click()
                            for run_primer_num in range(2,int(primer_num)+1):
                                if(run_primer_num<101):
                                    driver2.find_element_by_xpath("(//input[@name='ids'])["+str(run_primer_num)+"]").click()
                            driver2.find_element_by_xpath("//button[@type='button']").click()
                            sleep(10)
                            handles2 = driver2.window_handles 
                            driver2.switch_to.window(handles2[-1])  
                            sleep(2)
                            loop_primer_index_list = []
                            loop_primer_all = []
                            Loop_primer_index = driver2.find_element_by_xpath('//*[@id="1"]/tbody/tr[3]/td[2]').text
                            for run_id in range(1,int(primer_num)+1):
                                if(run_id<101):
                                    if(int(primer_num)>=100):
                                        addd = 100
                                    else:
                                        addd = int(primer_num)

                                    save_list = []
                                    for id_index in range(2,10):
                                        loop_primer_index = driver2.find_element_by_xpath('//*[@id="'+str(run_id)+'"]/tbody/tr[3]/td['+str(id_index)+']').text
                                        save_list.append(loop_primer_index)
                                    loop_primer_index = driver2.find_element_by_xpath('//*[@id="'+str(run_id)+'"]/tbody/tr[3]/td[10]/span').text
                                    save_list.append(loop_primer_index)
                                    loop_primer_all.append(save_list)
                                    loop_primer_index_list.append('primer'+str(run_id))
                                    save_list = []

                                    try:
                                        for id_index in range(2,10):
                                            loop_primer_index = driver2.find_element_by_xpath('//*[@id="'+str(run_id)+'"]/tbody/tr[4]/td['+str(id_index)+']').text
                                            save_list.append(loop_primer_index)
                                        loop_primer_index = driver2.find_element_by_xpath('//*[@id="'+str(run_id)+'"]/tbody/tr[4]/td[10]/span').text
                                        save_list.append(loop_primer_index)

                                        loop_primer_all.append(save_list)
                                        loop_primer_index_list.append('primer'+str(run_id))
                                    except:
                                        L = False

                                    save_list = []
                                    loop_primer_all.append(['------------------' for i in range(9)])
                                    loop_primer_index_list.append('*****')
                            loop_primer_pd = DataFrame(loop_primer_all,index=loop_primer_index_list,columns=columns)
                            loop_primer_pd.to_csv(save_excel_path+'_LoopPrimer_'+group_number+datetime.now().strftime('_%Y_%m_%d_%H_%M_%S')+'.csv')
                        except :
                            pass_num = False
                handles2 = driver2.window_handles
                cou2 = len(handles2)
                for closing in handles2:
                    driver2.switch_to.window(closing)
                    if(cou2 != 1):
                        driver2.close()
                        cou2 -= 1
                print('----Sec round loop primer search2__3')
                if(int(LF)!=0 and int(LB)!=0):
                    if(mode == 'Best'):
                        print('----Sec round loop primer search2__end')
                        return this_data_name+' : '+group_number ,this_data_name+' : '+group_number , LF , LB,Primer_sets,pieces,' '
                    elif(mode == 'Sec'):
                        print('----Sec round loop primer search2__end')
                        return this_data_name+' : '+group_number ,this_data_name+' : '+group_number , LF , LB,Primer_sets,pieces,Loop_primer_index
                elif(int(LF)==0 and int(LB)==0) :
                    print('----Sec round loop primer search2__end')
                    return this_data_name+' : '+group_number ,'X'  , LF , LB,Primer_sets,'X',' '
                else:
                    print('----Sec round loop primer search2__end')
                    return this_data_name+' : '+group_number ,'X'  , LF , LB,Primer_sets,pieces,Loop_primer_index

            D_group = []
            add_Page = 0
            if continue_position%100 == 0 :
                add_Page = 1
            for switch_to_window in range(1,Page-int(continue_position/100)+add_Page):
                print('Page'+str(int(continue_position/100)-add_Page+switch_to_window)+'')
                driver.switch_to.window(handles[-switch_to_window])
                sleep(2)


                #search id_
                times = 0
                list_primer_id = []
                try:
                    primer_id1 = driver.find_element_by_xpath('/html/body/form[1]/table/tbody/tr[6]/td[1]/span').text
                    primer_id1 = primer_id1.replace('[','');primer_id1 = primer_id1.replace(']','');times+=1;list_primer_id.append(primer_id1)
                    primer_id2 = driver.find_element_by_xpath('/html/body/form[1]/table/tbody/tr[7]/td[1]/span').text
                    primer_id2 = primer_id2.replace('[','');primer_id2 = primer_id2.replace(']','');times+=1;list_primer_id.append(primer_id2)
                    primer_id3 = driver.find_element_by_xpath('/html/body/form[1]/table/tbody/tr[8]/td[1]/span').text
                    primer_id3 = primer_id3.replace('[','');primer_id3 = primer_id3.replace(']','');times+=1;list_primer_id.append(primer_id3)
                    primer_id4 = driver.find_element_by_xpath('/html/body/form[1]/table/tbody/tr[9]/td[1]/span').text
                    primer_id4 = primer_id4.replace('[','');primer_id4 = primer_id4.replace(']','');times+=1;list_primer_id.append(primer_id4)
                    primer_id5 = driver.find_element_by_xpath('/html/body/form[1]/table/tbody/tr[10]/td[1]/span').text
                    primer_id5 = primer_id5.replace('[','');primer_id5 = primer_id5.replace(']','');times+=1;list_primer_id.append(primer_id5)
                except:
                    finish = True
                    

                if Default :
                    try:
                        driver.find_element_by_name("ids").click()
                        driver.find_element_by_xpath("(//input[@name='ids'])[2]").click()
                        driver.find_element_by_xpath("(//input[@name='ids'])[3]").click()
                        driver.find_element_by_xpath("(//input[@name='ids'])[4]").click()
                        driver.find_element_by_xpath("(//input[@name='ids'])[5]").click()
                    except:
                        finish = True
                else:
                    try:
                        # inner primer
                        driver.find_element_by_name("ids").click()
                        Fail_order = []
                        for each_id_order in range(99): #99
                            try:
                                driver.find_element_by_xpath("(//input[@name='ids'])["+str(2+each_id_order)+"]").click()
                            except:
                                Fail_order.append(each_id_order)
                        Fail_order2 = []
                        for each_id_order in Fail_order:
                            try:
                                driver.find_element_by_xpath("(//input[@name='ids'])["+str(2+each_id_order)+"]").click()
                            except:
                                Fail_order2.append(each_id_order)

                        for each_id_order in Fail_order2:
                            try:
                                driver.find_element_by_xpath("(//input[@name='ids'])["+str(2+each_id_order)+"]").click()
                            except:
                                finish = True
                    except:
                        finish = True
                
                driver.find_element_by_xpath("//button[@type='button']").click() # Next page
                sleep(2)
                Handles = driver.window_handles 
                driver.switch_to.window(Handles[-1])
                Group1 = []
                try :
                    object_dir = save_excel_path + '/'
#                         if(choose != 'you have selected D'):
                    if not path.exists(object_dir):
                        makedirs(object_dir)
                    
                    save_excel_path2 = save_excel_path + '/' + save_excel_path[save_excel_path.rfind('/')+1:]
                    save_Count_success_primer = save_excel_path[:save_excel_path.rfind('/')+1]

                    if(running):
                        if continue_position % 100 != 1 and switch_to_window == 1:
                            print('pass_one')
                        else: 
                            move_100_case_ = 0
                            if continue_position % 100 == 0 :
                                move_100_case_ = 1
                            if Default:
                                Primer_ID = primer_id1
                            else:
                                Primer_ID = str(1+(int((continue_position-move_100_case_)/100)+switch_to_window-1)*100)
                            Group1,dimer_minimum_dG = run_primer(Primer_ID,Group1,'Group'+Primer_ID,save_excel_path2+'_Inner_Primer_'+Primer_ID+'.fasta') #switch_to_window
                            print('--Run primer ready...')
                            Group1.to_excel(save_excel_path2+'_Inner_Primer_'+Primer_ID+datetime.now().strftime('_%Y_%m_%d_%H_%M_%S')+'.xlsx',encoding='utf-8') #,encoding='utf-8'
                            print('Group'+Primer_ID)

                            This_data_success = True
                            if(choose != 'you have selected D'):
                                try:
                                    print(now_path+save_excel_path2+'_Inner_Primer_'+Primer_ID+'.fasta')
                                    write_str,write_str2,LF,LB,Primer_sets,pieces,Lx = copy_to_save_path(choose,save_excel_path2,user_name,'Group'+Primer_ID,n2,  now_path+save_excel_path2+'_Inner_Primer_'+Primer_ID+'.fasta')
                                    print('----this data success')
                                    print(now_path+save_Count_success_primer+'Final_'+this_data_name+'.txt')
                                    print(now_path+object_dir+this_data_name+'.txt')
                                except:
                                    This_data_success = False
                                    print('----this data fail')
                                    
                                if This_data_success :
                                    with open(now_path+save_Count_success_primer+'Final_'+this_data_name+'.txt','a') as file :
                                        file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    if(write_str2!='X'):
                                        with open(now_path+save_Count_success_primer+'Final_LF&LB_'+this_data_name+'.txt','a') as file :
                                            file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    if(write_str2!='X' and Primer_sets != '0'):
                                        with open(now_path+save_Count_success_primer+'Final_Group_'+this_data_name+'.txt','a') as file :
                                            file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    with open(now_path+object_dir+this_data_name+'.txt','a') as file :
                                        file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    with open(now_path+object_dir+this_data_name+'_Dimer_minimum_dG.txt','a') as file :
                                        file.write('Group'+Primer_ID+' '+dimer_minimum_dG+'\n')
                    if(running):
                        usually = 1
                        move_100_case = 0
                        if continue_position % 100 != 1 and switch_to_window == 1:
                            usually = int(continue_position % 100) -1 
                            if usually == -1 :
                                usually = 99
                        if continue_position % 100 == 0 :
                                move_100_case = 1
                        if Default :
                            last_Primer_ID = times
                        else:
                            last_Primer_ID = 100
                        for running_other in range(usually,last_Primer_ID): #100 # each_page
                            Group_other = []
                            if Default:
                                Primer_ID = list_primer_id[running_other]
                            else:
                                Primer_ID = str(1+(int((continue_position-move_100_case)/100)+switch_to_window-1)*100+running_other)
                            Group_other,dimer_minimum_dG = run_primer(Primer_ID,Group_other,'Group'+Primer_ID,save_excel_path2+'_Inner_Primer_'+Primer_ID+'.fasta')
                            Group_other.to_excel(save_excel_path2+'_Inner_Primer_'+Primer_ID+datetime.now().strftime('_%Y_%m_%d_%H_%M_%S')+'.xlsx',encoding='utf-8')
                            print('Group'+Primer_ID)

                            This_data_success = True
                            if(choose != 'you have selected D'):
                                try:
                                    print(save_excel_path2+'_Inner_Primer_'+Primer_ID+'.fasta')
                                    write_str,write_str2,LF,LB,Primer_sets,pieces,Lx = copy_to_save_path(choose,save_excel_path2,user_name,'Group'+Primer_ID,n2,   now_path+save_excel_path2+'_Inner_Primer_'+Primer_ID+'.fasta')
                                except:
                                    This_data_success = False
                                if This_data_success :
                                    with open(now_path+save_Count_success_primer+'Final_'+this_data_name+'.txt','a') as file :
                                        file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    if(write_str2!='X'):
                                        with open(now_path+save_Count_success_primer+'Final_LF&LB_'+this_data_name+'.txt','a') as file :
                                            file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    if(write_str2!='X' and Primer_sets != '0'):
                                        with open(now_path+save_Count_success_primer+'Final_Group_'+this_data_name+'.txt','a') as file :
                                            file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    with open(now_path+object_dir+this_data_name+'.txt','a') as file :
                                        file.write(write_str+'\nLF : '+LF+'\nLB : '+LB+'\nSets : '+Primer_sets+'\nPrimer pieces : '+pieces+' '+Lx+'\n\n')
                                    with open(now_path+object_dir+this_data_name+'_Dimer_minimum_dG.txt','a') as file :
                                        file.write('Group'+str(1+(int((continue_position-move_100_case)/100)+switch_to_window-1)*100+running_other)+' '+dimer_minimum_dG+'\n')
                except :
                    stop = True
                driver.close()
            sleep_time = randint(1,3)
            sleep(sleep_time)
            handles = driver.window_handles
            cou = len(handles)
            for closing in handles:
                driver.switch_to.window(closing)
                if(cou != 1):
                    driver.close()
                    cou -= 1
        print('Over')
            
            
            
Stop_num = 0
print('open path : '+TOP_path)
for root, dirs, files in walk(TOP_path):
    for each_paper in files :
        this_data_name = each_paper[:each_paper.rfind('.')]
        if(each_paper[each_paper.rfind('.'):]=='.fasta' or each_paper[each_paper.rfind('.'):]=='.fa' or each_paper[each_paper.rfind('.'):]=='.fas'):       
            Stop_num+=1
            if(Stop_num%100==0):
                sleep(300)
            if(each_paper[each_paper.rfind('.'):]=='.fasta') :
                data_name_end =  -6
            elif(each_paper[each_paper.rfind('.'):]=='.fas') :
                data_name_end =  -4
            elif(each_paper[each_paper.rfind('.'):]=='.fa') :
                data_name_end =  -3
            upload_data = TOP_path + each_paper #'/usr/src/app/fasta_input/Input_no13/tfo_no_13_764_to_774_score_9_.fasta'
            if(save_path=='/'):
                save_excel_path = upload_data[:data_name_end]+'_PrimerList'
            else:
                save_excel_path = save_path+upload_data[upload_data.rfind('/')+1:data_name_end]+'_PrimerList'
    
            print('--read : '+TOP_path+each_paper)
            with open (TOP_path+each_paper,'r') as file :
                num = 0
                Target_Sequence_for_All = ''
                for line in file :
                    if num >= 1:
                        Target_Sequence_for_All += line.replace('\n','').upper()
                    num += 1       
            print('--target : '+Target_Sequence_for_All)
            
            print('fasta : '+each_paper)
            print('save path : '+save_path)
            try:
                with open(save_path+'Final_'+this_data_name+'.txt','r') as f_again :
                    now = f_again.read()
                    nows = now.split('\n')
                    last = nows[-7]
                    last_number =  last[last.find(": Group")+len(": Group"):]
                    print('Last : ',int(last_number))
                    if int(last_number) != 1000 :
                        print('Again')
                        this_fasta_start_position = int(last_number)+1
                    else:
                        this_fasta_start_position = 1 # Next
            except:
                this_fasta_start_position = 1 # New
            print('this_fasta_start_position : ',this_fasta_start_position)
            Progress(this_fasta_start_position)
try:
    driver.quit()
    driver2.quit()
except:
    try:
        driver2.quit()
        driver.quit()
    except:
        over = True