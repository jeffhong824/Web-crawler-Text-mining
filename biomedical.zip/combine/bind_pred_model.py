from TFO_LAMP_binding_prediction_model import input_target_path,get_info
import sys
import os

Top = sys.argv[1]#3 
TTS_result_path = sys.argv[2] #'TFO.csv'
LAMP_result_path = sys.argv[3] #'Output_no13/'
output_file_path = sys.argv[4] #'output/'
output_data_name = sys.argv[5] #'no13'

now_path = os.getcwd() + '/'
print('dir path : '+ now_path)

if not os.path.isdir(now_path+output_file_path):
    os.mkdir(now_path+output_file_path)

mode = 1
#mode = 2

if mode == 1 :
    print(Top)
    input_target_path(Top,TTS_result_path,LAMP_result_path,output_file_path,output_data_name)